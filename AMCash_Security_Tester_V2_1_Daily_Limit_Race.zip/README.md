# AMCash Security Tester V2
Put your three raw Burp requests here as `inquire.txt`, `redeem.txt`, `reverse.txt`.
Edit `config.json` and replace `YOUR-UAT-HOST` in BOTH host fields.
Use only controlled UAT collectors and the smallest approved redemption value.

Run:
    export AMCASH_JWT='FRESH_TEST_TOKEN'
    python3 amcash_v2.py

Menu items 3-6 change points and require typing ENABLE.
Option 7 uses only the controlled Collector B / confirmation you place in config.json.
Option 11 creates HTML, JSON and CSV reports under amcash-v2-results/.

Hard safety limits: 250 total requests and max 5 concurrent workers.
The tool intentionally does not enumerate/brute-force unknown collector or confirmation numbers.

## V2.1 — Daily-limit race test
Menu option 12 sends exactly 10 synchronized Redeem requests. Each request receives a
different 12-digit `traceId`. You choose the per-request redemption amount at runtime
(default `$5.00`) and enter the documented daily limit for your notes (default `$10.00`).

The test:
1. Inquires the starting state.
2. Builds 10 Redeem requests with unique traceIds.
3. Holds all 10 threads at a barrier.
4. Releases them together.
5. Records responseCode, txnConfirmationNumber and idempotencyId.
6. Inquires the final authoritative state.
7. Prints the number of approved responses and unique transaction/idempotency pairs.

Use only a controlled UAT collector. If `$5` is not a valid redemption unit, enter the
minimum valid amount instead. The authoritative ledger/balance delta determines whether
the daily limit was actually exceeded; multiple `0000` responses alone are not sufficient.
