#!/usr/bin/env python3
import argparse,copy,csv,html,http.client,json,os,ssl,sys,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
MAXREQ=250; MAXWORK=5
def raw(fn):
 s=Path(fn).read_text(errors="replace").replace("\r\n","\n");h,_,b=s.partition("\n\n");ls=h.splitlines();p=ls[0].split();hs={};cur=None
 for x in ls[1:]:
  if x[:1].isspace() and cur: hs[cur]+=x.strip()
  elif ":" in x: k,v=x.split(":",1);cur=k.strip();hs[cur]=v.strip()
 return {"method":p[0],"path":p[1],"headers":hs,"body":json.loads(b)}
def seth(h,n,v):
 for k in list(h):
  if k.lower()==n.lower():h[k]=v;return
 h[n]=v
class H:
 def __init__(self,c,t):
  self.c=c;self.t=t;self.n=0;self.r=[];self.o=Path(c["output"]);self.o.mkdir(exist_ok=True)
  self.q={k:raw(v) for k,v in c["requests"].items()}
 def send(self,e,b=None,l=None):
  if self.n>=min(self.c["max_requests"],MAXREQ):raise RuntimeError("request cap")
  self.n+=1;r=self.q[e];hs=dict(r["headers"])
  for k in list(hs):
   if k.lower() in ("authorization","host","content-length","connection","accept-encoding","postman-token"):hs.pop(k)
  seth(hs,"Host",self.c["host"]);seth(hs,"Content-Type","application/json");seth(hs,"Authorization","Bearer "+self.t)
  obj=copy.deepcopy(r["body"] if b is None else b);data=json.dumps(obj).encode();ctx=ssl.create_default_context();cn=http.client.HTTPSConnection(self.c["host"],timeout=20,context=ctx);st=time.time()
  try:
   cn.request(r["method"],r["path"],data,hs);x=cn.getresponse();z=x.read()
   try:j=json.loads(z.decode())
   except:j={}
   rec={"label":l or e,"endpoint":e,"http":x.status,"responseCode":str(j.get("responseCode","")),"message":j.get("message"),"ms":round((time.time()-st)*1000,1),"request":obj,"response":j}
   self.r.append(rec);print(f"{rec['label']:<44} HTTP {x.status} code={rec['responseCode']}");return rec
  finally:cn.close()
 def baseline(self):self.send("inquire",l="baseline:inquire")
 def inquire(self):
  b=self.q["inquire"]["body"]
  cases=[("basket:zero","postTaxBasketAmount","0.00"),("basket:negative","postTaxBasketAmount","-10.00"),("basket:9.99","postTaxBasketAmount","9.99"),("basket:10.01","postTaxBasketAmount","10.01"),("collector:type","collectorNumber",12345),("date:old","dateTime","1977-09-08T15:17:53.395-0400"),("date:future","dateTime","2099-01-01T00:00:00.000+0000"),("trace:zeros","traceId","000000000000")]
  for l,f,v in cases:
   if f in b:x=copy.deepcopy(b);x[f]=v;self.send("inquire",x,"inquire:"+l)
 def fuzz(self):
  b=self.q["inquire"]["body"]
  for f in b:
   for n,v in [("null",None),("empty",""),("array",[]),("long","A"*128)]:
    x=copy.deepcopy(b);x[f]=v;self.send("inquire",x,f"fuzz:{f}:{n}")
 def redeem(self):
  b=self.q["redeem"]["body"];self.send("redeem",l="redeem:baseline")
  for l,v in [("zero","0.00"),("negative","-10.00"),("9.99","9.99"),("10.01","10.01"),("precision","10.001"),("type",10.0)]:
   x=copy.deepcopy(b);x["dollarRedeemRequest"]=v;self.send("redeem",x,"redeem:"+l)
  self.send("redeem",l="redeem:exact-replay")
 def e2e(self):
  self.send("inquire",l="e2e:before");r=self.send("redeem",l="e2e:redeem");self.send("inquire",l="e2e:after-redeem");c=(r["response"] or {}).get("txnConfirmationNumber")
  if not c:print("[!] no confirmation; reverse skipped");return
  b=copy.deepcopy(self.q["reverse"]["body"]);b["redemptionConfirmationNum"]=str(c);v=self.send("reverse",b,"e2e:reverse");self.send("inquire",l="e2e:after-reverse");return b,v
 def replay(self):
  r=self.send("redeem",l="replay:redeem:first");self.send("redeem",l="replay:redeem:second");c=(r["response"] or {}).get("txnConfirmationNumber")
  if c:
   b=copy.deepcopy(self.q["reverse"]["body"]);b["redemptionConfirmationNum"]=str(c);v=self.send("reverse",b,"replay:reverse:first");self.send("reverse",b,"replay:reverse:second");rc=(v["response"] or {}).get("txnConfirmationNumber")
   if rc:x=copy.deepcopy(b);x["redemptionConfirmationNum"]=str(rc);self.send("reverse",x,"replay:reversal-confirmation")
  self.send("inquire",l="replay:final-balance")
 def race(self):
  w=min(self.c["workers"],MAXWORK)
  with ThreadPoolExecutor(max_workers=w) as ex:
   fs=[ex.submit(self.send,"redeem",None,f"race:redeem:{i+1}") for i in range(w)]
   for f in as_completed(fs):f.result()
  self.send("inquire",l="race:after")
 def bola(self):
  z=self.c.get("controlled_cross_tests",{});b=z.get("collector_b");cf=z.get("collector_b_redemption_confirmation")
  if not b:print("[!] configure collector_b first");return
  x=copy.deepcopy(self.q["inquire"]["body"]);x["collectorNumber"]=str(b);self.send("inquire",x,"bola:inquire:B")
  if cf:x=copy.deepcopy(self.q["reverse"]["body"]);x["redemptionConfirmationNum"]=str(cf);self.send("reverse",x,"bola:reverse:A-with-B-confirmation")
 def report(self):
  (self.o/"results.json").write_text(json.dumps(self.r,indent=2))
  with open(self.o/"results.csv","w",newline="") as f:
   w=csv.writer(f);w.writerow(["test","endpoint","http","code","message","ms"]);[w.writerow([x["label"],x["endpoint"],x["http"],x["responseCode"],x["message"],x["ms"]]) for x in self.r]
  rows="".join(f"<tr><td>{html.escape(x['label'])}</td><td>{x['http']}</td><td>{html.escape(x['responseCode'])}</td><td>{html.escape(str(x['message']))}</td><td>{x['ms']}</td></tr>" for x in self.r)
  (self.o/"report.html").write_text(f"<h1>AMCash V2 Report</h1><p>{len(self.r)} requests. JWT is not stored.</p><table border=1 cellpadding=6><tr><th>Test</th><th>HTTP</th><th>Code</th><th>Message</th><th>ms</th></tr>{rows}</table>")
  print("[+] report:",self.o/"report.html")
def enable():return input("Type ENABLE for state-changing tests: ").strip()=="ENABLE"
def menu(h):
 while 1:
  print("\nAMCash Security Tester V2\n1 Baseline Inquire\n2 Inquire logic tests\n3 Redeem tests [STATE]\n4 E2E Redeem->Reverse [STATE]\n5 Replay/idempotency [STATE]\n6 Bounded race [STATE]\n7 Cross-collector BOLA\n8 Timestamp/trace tests\n9 Inquire field fuzzing\n10 Safe read-only suite\n11 Generate report\n0 Exit")
  c=input("Select: ").strip()
  try:
   if c=="1":h.baseline()
   elif c=="2":h.inquire()
   elif c=="3" and enable():h.redeem()
   elif c=="4" and enable():h.e2e()
   elif c=="5" and enable():h.replay()
   elif c=="6" and enable():h.race()
   elif c=="7":h.bola()
   elif c=="8":h.inquire()
   elif c=="9":h.fuzz()
   elif c=="10":h.baseline();h.inquire()
   elif c=="11":h.report()
   elif c=="0":h.report();break
  except Exception as e:print("[!]",e)
def main():
 p=argparse.ArgumentParser();p.add_argument("--config",default="config.json");p.add_argument("--jwt",default=os.getenv("AMCASH_JWT"));a=p.parse_args();c=json.loads(Path(a.config).read_text())
 if c["host"]!=c["allow_host"]:sys.exit("host/allow_host mismatch")
 if not a.jwt:sys.exit("Set AMCASH_JWT")
 if c["workers"]>MAXWORK or c["max_requests"]>MAXREQ:sys.exit("safety limit exceeded")
 menu(H(c,a.jwt))
if __name__=="__main__":main()
