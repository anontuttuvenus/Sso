# AMCash Security Tester V2
Put your three raw Burp requests here as `inquire.txt`, `redeem.txt`, `reverse.txt`.
Edit `config.json` and replace `YOUR-UAT-HOST` in BOTH host fields.
Use only controlled UAT collectors and the smallest approved redemption value.

Run:
    export AMCASH_JWT='FRESH_TEST_TOKEN'
    python3 amcash_v2.py

Menu items 3-6 change points and require typing ENABLE.
Option 7 uses only the controlled Collector B / confirmation you place in config.json.
Option 11 creates HTML, JSON and CSV reports under amcash-v2-results/.

Hard safety limits: 250 total requests and max 5 concurrent workers.
The tool intentionally does not enumerate/brute-force unknown collector or confirmation numbers.
