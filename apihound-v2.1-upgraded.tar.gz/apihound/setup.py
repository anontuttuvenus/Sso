from setuptools import find_packages, setup

setup(
    name="apihound",
    version="2.1.0",
    description="OWASP API Security Top 10 Scanner — Automated API Penetration Testing",
    author="APIHound",
    python_requires=">=3.9",
    py_modules=["apihound"],
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "templates": ["report.html"],
    },
    install_requires=[
        "httpx[http2]>=0.27.0",
        "pyyaml>=6.0",
        "jinja2>=3.1",
        "rich>=13.0",
        "click>=8.1",
        "jsonschema>=4.20",
    ],
    entry_points={"console_scripts": ["apihound=apihound:main"]},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Information Technology",
        "Topic :: Security",
        "Programming Language :: Python :: 3",
    ],
)
