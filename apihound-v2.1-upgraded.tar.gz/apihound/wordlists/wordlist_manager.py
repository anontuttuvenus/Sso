"""
APIHound — Wordlist Manager
Built-in API-focused wordlists + SecLists integration.
"""
import os
import logging
from typing import Optional

logger = logging.getLogger("apihound.wordlists")

# Base directory for bundled wordlists
_DIR = os.path.dirname(os.path.abspath(__file__))


class WordlistManager:
    """Manage built-in and external wordlists for endpoint/parameter fuzzing."""

    def __init__(self, seclists_path: Optional[str] = None):
        self.seclists_path = seclists_path  # e.g., /opt/seclists

    def get_api_endpoints(self) -> list:
        """Common API endpoint paths (SecLists-style)."""
        return _API_ENDPOINTS

    def get_api_params(self) -> list:
        """Common API parameter names."""
        return _API_PARAMS

    def get_api_versions(self) -> list:
        """API version path prefixes."""
        return _API_VERSIONS

    def get_usernames(self) -> list:
        """Common usernames for auth testing."""
        return _USERNAMES

    def get_passwords(self) -> list:
        """Common passwords for auth testing."""
        return _PASSWORDS

    def load_file(self, path: str) -> list:
        """Load wordlist from file, one entry per line."""
        try:
            with open(path) as f:
                return [line.strip() for line in f if line.strip() and not line.startswith("#")]
        except FileNotFoundError:
            logger.warning(f"Wordlist not found: {path}")
            return []

    def load_seclists(self, relative_path: str) -> list:
        """Load a SecLists wordlist by relative path."""
        if not self.seclists_path:
            logger.warning("SecLists path not configured")
            return []
        full_path = os.path.join(self.seclists_path, relative_path)
        return self.load_file(full_path)


# =============================================================================
# Built-in wordlists (curated from SecLists, common-api-paths, and experience)
# =============================================================================

_API_ENDPOINTS = [
    # Authentication & Users
    "login", "logout", "register", "signup", "signin", "auth", "authenticate",
    "token", "refresh", "verify", "confirm", "reset", "forgot",
    "password", "password/reset", "password/change",
    "users", "user", "me", "profile", "account", "accounts",
    "users/me", "user/profile", "user/settings",
    # CRUD resources
    "items", "item", "products", "product", "orders", "order",
    "posts", "post", "comments", "comment", "messages", "message",
    "files", "file", "uploads", "upload", "download",
    "documents", "document", "images", "image",
    "categories", "category", "tags", "tag",
    "notifications", "notification", "events", "event",
    "payments", "payment", "invoices", "invoice",
    "subscriptions", "subscription", "plans", "plan",
    "reviews", "review", "ratings", "rating",
    "search", "filter", "query", "find", "lookup",
    # Admin/Management
    "admin", "admin/users", "admin/settings", "admin/config",
    "admin/logs", "admin/dashboard", "admin/reports",
    "manage", "management", "panel", "console",
    "roles", "role", "permissions", "permission",
    "groups", "group", "teams", "team",
    # System/Health
    "health", "healthcheck", "health/live", "health/ready",
    "status", "ping", "version", "info",
    "metrics", "stats", "statistics",
    "config", "configuration", "settings",
    "logs", "audit", "audit-log",
    # API discovery
    "api", "api-docs", "docs", "documentation",
    "swagger", "swagger.json", "swagger.yaml",
    "openapi", "openapi.json", "openapi.yaml",
    "graphql", "graphiql", "playground",
    "schema", "schemas",
    # Debug/Development (should not be in production)
    "debug", "debug/vars", "debug/pprof",
    "test", "testing", "dev", "development",
    "staging", "internal", "private",
    "actuator", "actuator/env", "actuator/health",
    "actuator/info", "actuator/beans", "actuator/mappings",
    "env", "environment", "phpinfo",
    "trace", "dump", "backup",
    # Webhooks/Integrations
    "webhooks", "webhook", "hooks", "hook",
    "callback", "callbacks", "integrations",
    "connect", "oauth", "oauth/authorize", "oauth/token",
    "sso", "saml", "oidc",
    # Data export/import
    "export", "import", "bulk", "batch",
    "reports", "report", "analytics",
    "csv", "excel", "pdf",
]

_API_PARAMS = [
    # Identity
    "id", "uid", "user_id", "userId", "account_id", "accountId",
    "uuid", "guid", "pk", "key", "ref", "slug",
    "username", "user", "email", "name",
    # Auth
    "token", "access_token", "api_key", "apiKey", "auth",
    "session", "session_id", "sessionId", "jwt",
    "password", "passwd", "secret", "credential",
    # Pagination
    "page", "per_page", "perPage", "limit", "offset",
    "size", "count", "start", "end",
    "cursor", "after", "before", "next", "prev",
    "sort", "order", "orderBy", "sortBy", "direction",
    # Filtering
    "filter", "query", "q", "search", "keyword",
    "status", "state", "type", "category",
    "from", "to", "since", "until", "date",
    "min", "max", "range", "between",
    # URLs/Resources
    "url", "uri", "path", "file", "filename",
    "src", "source", "dest", "destination",
    "redirect", "redirect_uri", "redirect_url", "callback",
    "return_url", "returnUrl", "next", "continue",
    "link", "href", "target", "endpoint",
    # Content
    "body", "content", "text", "message", "data",
    "title", "description", "summary", "note",
    "comment", "review", "feedback",
    # Configuration
    "format", "output", "encoding", "lang", "locale",
    "version", "v", "fields", "include", "exclude",
    "expand", "embed", "populate",
    "verbose", "debug", "trace", "log_level",
    # Actions
    "action", "method", "operation", "cmd", "command",
    "exec", "run", "process", "task",
    "role", "admin", "is_admin", "privilege",
]

_API_VERSIONS = [
    "/v1", "/v2", "/v3", "/v4", "/v5",
    "/api/v1", "/api/v2", "/api/v3", "/api/v4", "/api/v5",
    "/api/1.0", "/api/2.0", "/api/3.0",
    "/api/1", "/api/2", "/api/3",
    "/rest/v1", "/rest/v2", "/rest/v3",
    "/api/latest", "/api/beta", "/api/alpha",
    "/api/dev", "/api/staging", "/api/test",
    "/api/old", "/api/legacy", "/api/deprecated",
    "/api/internal", "/api/private", "/api/public",
]

_USERNAMES = [
    "admin", "administrator", "root", "user", "test",
    "guest", "demo", "operator", "manager", "staff",
    "support", "help", "info", "api", "service",
    "system", "backup", "dev", "developer", "staging",
    "qa", "tester", "security", "audit", "monitor",
]

_PASSWORDS = [
    "password", "123456", "admin", "12345678", "qwerty",
    "abc123", "password1", "1234567", "letmein", "welcome",
    "monkey", "dragon", "master", "login", "changeme",
    "Password1", "Password123", "Admin123", "Welcome1", "P@ssw0rd",
    "test", "root", "toor", "pass", "1q2w3e4r",
]
