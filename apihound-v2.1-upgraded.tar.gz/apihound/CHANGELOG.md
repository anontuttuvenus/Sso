# Changelog

## 2.1.0

- Added local OpenAPI/Swagger `$ref` resolution, path-level parameters, server variables, operation servers, examples/defaults, and Swagger 2 response schemas.
- Added schema-aware request construction so required path/query/header/body values can be materialized from the API specification.
- Reworked BOLA detection around differential responses and explicit `--user-id` / `--user-id-other` evidence; production mode avoids automatic state-changing BOLA probes.
- Added normalized response comparison that ignores common volatile fields such as timestamps and request IDs.
- Added network retries with exponential backoff and richer request statistics.
- Redacts Authorization, Cookie, Set-Cookie, API-key and proxy-auth values from raw report evidence.
- Added finding deduplication.
- Added SARIF 2.1.0 output for CI/security tooling.
- Added repeatable `--header`, `--retries`, `--max-endpoints`, and `--version` CLI options plus stricter option validation.
- Added parser/request-builder/redaction regression tests.
