import json
import unittest

from core.config import ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import OpenAPIParser
from core.request_builder import RequestBuilder


class APIHoundV21Tests(unittest.TestCase):
    def test_openapi3_ref_path_params_and_body(self):
        spec = {
            "openapi": "3.0.3",
            "servers": [{"url": "https://{env}.example.test/api", "variables": {"env": {"default": "dev"}}}],
            "paths": {
                "/users/{id}": {
                    "parameters": [{"$ref": "#/components/parameters/UserId"}],
                    "post": {
                        "requestBody": {"content": {"application/json": {"schema": {"$ref": "#/components/schemas/UserUpdate"}}}},
                        "responses": {"200": {"content": {"application/json": {"schema": {"$ref": "#/components/schemas/User"}}}}}
                    }
                }
            },
            "components": {
                "parameters": {"UserId": {"name": "id", "in": "path", "required": True, "schema": {"type": "integer", "example": 42}}},
                "schemas": {
                    "UserUpdate": {"type": "object", "required": ["name"], "properties": {"name": {"type": "string", "example": "Ada"}, "optional": {"type": "string"}}},
                    "User": {"type": "object", "properties": {"id": {"type": "integer"}}}
                }
            }
        }
        eps = OpenAPIParser().parse(json.dumps(spec))
        self.assertEqual(len(eps), 1)
        ep = eps[0]
        self.assertEqual(ep.full_url, "https://dev.example.test/api/users/{id}")
        self.assertEqual(ep.parameters[0].example, 42)
        self.assertEqual(ep.request_body_schema["properties"]["name"]["example"], "Ada")
        self.assertIn("200", ep.response_schemas)
        url, query, headers, body = RequestBuilder().build(ep)
        self.assertEqual(url, "https://dev.example.test/api/users/42")
        self.assertEqual(body, {"name": "Ada"})

    def test_swagger2_path_level_parameter(self):
        spec = {"swagger": "2.0", "host": "api.example.test", "basePath": "/v1", "paths": {
            "/orders/{orderId}": {"parameters": [{"name": "orderId", "in": "path", "required": True, "type": "integer", "default": 7}], "get": {"responses": {"200": {"schema": {"type": "object"}}}}}
        }}
        ep = OpenAPIParser().parse(json.dumps(spec))[0]
        self.assertEqual(RequestBuilder().build(ep)[0], "https://api.example.test/v1/orders/7")
        self.assertIn("200", ep.response_schemas)

    def test_sensitive_headers_redacted(self):
        client = HTTPClient(ScanConfig())
        try:
            raw = client.build_raw_request("GET", "https://example.test/a", {"Authorization": "Bearer secret", "X-API-Key": "abc", "X-Test": "ok"})
            self.assertNotIn("secret", raw)
            self.assertNotIn("abc", raw)
            self.assertIn("X-Test: ok", raw)
        finally:
            client.close()


if __name__ == "__main__":
    unittest.main()
