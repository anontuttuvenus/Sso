"""Small response-comparison helpers used to reduce scanner false positives."""
from __future__ import annotations

import hashlib
import json
import re
from difflib import SequenceMatcher
from typing import Any, Optional

_VOLATILE_KEYS = {"timestamp", "time", "requestid", "request_id", "traceid", "trace_id", "correlationid", "correlation_id"}


def _normalize_json(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _normalize_json(v) for k, v in sorted(value.items()) if k.lower() not in _VOLATILE_KEYS}
    if isinstance(value, list):
        return [_normalize_json(v) for v in value]
    return value


def normalized_body(resp) -> str:
    if resp is None:
        return ""
    text = resp.text or ""
    ctype = (resp.headers.get("content-type", "") if hasattr(resp, "headers") else "").lower()
    if "json" in ctype or text.lstrip().startswith(("{", "[")):
        try:
            obj = _normalize_json(resp.json())
            return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        except Exception:
            pass
    text = re.sub(r"\b[0-9a-f]{8}-[0-9a-f-]{27,}\b", "<uuid>", text, flags=re.I)
    text = re.sub(r"\b\d{10,13}\b", "<timestamp>", text)
    return re.sub(r"\s+", " ", text).strip()


def similarity(a, b) -> float:
    return SequenceMatcher(None, normalized_body(a), normalized_body(b)).ratio()


def materially_different(a, b, threshold: float = 0.80) -> bool:
    if a is None or b is None:
        return False
    if a.status_code != b.status_code:
        return True
    return similarity(a, b) < threshold


def fingerprint(resp) -> str:
    body = normalized_body(resp)
    status = getattr(resp, "status_code", 0)
    return hashlib.sha256(f"{status}:{body}".encode()).hexdigest()[:16]
