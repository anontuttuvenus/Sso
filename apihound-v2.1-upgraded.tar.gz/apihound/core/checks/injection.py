"""
APIHound — Injection Checks
SQLi, NoSQLi, XSS, XXE, SSTI, CMDi, Path Traversal across all API parameters.
"""
import json
import logging
import re
import time
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.injection")


class InjectionCheck:
    CHECK_ID = "INJ"
    OWASP_REF = "https://owasp.org/www-project-api-security/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting injection checks")

        for ep in endpoints:
            self._test_sqli(ep)
            self._test_nosqli(ep)
            self._test_xss(ep)
            self._test_ssti(ep)
            self._test_cmdi(ep)
            self._test_path_traversal(ep)
            if ep.method in ("POST", "PUT", "PATCH"):
                self._test_xxe(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    # ---- SQL Injection ----

    def _test_sqli(self, ep: APIEndpoint):
        """Test for SQL injection in query and body parameters."""
        # Error-based SQLi
        for param in self._get_injectable_params(ep):
            for payload in PayloadDB.SQLI_PAYLOADS[:10]:
                resp = self._inject_param(ep, param.name, payload, param.location)
                if not resp:
                    continue
                if self._detect_sqli_error(resp):
                    self._add_finding(
                        "INJ-SQLI", "CRITICAL", ep, payload, param.name, resp,
                        "SQL injection — error-based",
                        "SQL error detected in response after injecting SQL payload.",
                        cvss=9.8,
                    )
                    return

        # Time-based blind SQLi (test only a couple payloads — expensive)
        time_payloads = ["' OR SLEEP(3)--", "'; WAITFOR DELAY '0:0:3'--", "' OR pg_sleep(3)--"]
        for param in self._get_injectable_params(ep)[:2]:
            for payload in time_payloads:
                start = time.monotonic()
                resp = self._inject_param(ep, param.name, payload, param.location)
                elapsed = time.monotonic() - start
                if elapsed >= 2.5:
                    self._add_finding(
                        "INJ-SQLI-BLIND", "HIGH", ep, payload, param.name, resp,
                        "SQL injection — time-based blind",
                        f"Response delayed by {elapsed:.1f}s, indicating blind SQLi.",
                        cvss=8.6,
                    )
                    return

    def _detect_sqli_error(self, resp) -> bool:
        """Detect SQL error messages in response."""
        if not resp or resp.status_code not in (200, 400, 500):
            return False
        body = resp.text.lower()
        sql_errors = [
            "you have an error in your sql syntax", "mysql_fetch",
            "warning: mysql", "unclosed quotation mark",
            "quoted string not properly terminated",
            "pg_query", "pg_exec", "postgresql",
            "ora-01756", "ora-00933", "oracle error",
            "microsoft ole db provider for sql",
            "mssql_query", "sql server",
            "sqlite3.operationalerror", "sqlite_error",
            "sqlstate[", "pdo exception", "sql syntax",
            "unterminated string", "invalid query",
        ]
        return any(err in body for err in sql_errors)

    # ---- NoSQL Injection ----

    def _test_nosqli(self, ep: APIEndpoint):
        """Test for NoSQL injection."""
        if ep.method not in ("POST", "PUT", "PATCH"):
            return

        for payload in PayloadDB.NOSQLI_PAYLOADS[:8]:
            if isinstance(payload, dict):
                # Inject operator into body fields
                for param in self._get_body_fields(ep):
                    body = {param: payload}
                    resp = self.client.request(ep.method, ep.full_url, json_body=body)
                    if resp and resp.status_code == 200 and len(resp.text) > 50:
                        self._add_finding(
                            "INJ-NOSQLI", "HIGH", ep, str(payload), param, resp,
                            "NoSQL injection",
                            f"NoSQL operator {payload} in field '{param}' returned data.",
                            cvss=8.6,
                        )
                        return
            elif isinstance(payload, str):
                for param in self._get_injectable_params(ep):
                    resp = self._inject_param(ep, param.name, payload, param.location)
                    if resp and resp.status_code == 200:
                        body = resp.text.lower()
                        if any(s in body for s in ["mongodb", "mongoose", "$where"]):
                            self._add_finding(
                                "INJ-NOSQLI", "HIGH", ep, payload, param.name, resp,
                                "NoSQL injection",
                                "NoSQL-related error/data returned.",
                                cvss=8.6,
                            )
                            return

    # ---- Cross-Site Scripting (XSS) ----

    def _test_xss(self, ep: APIEndpoint):
        """Test for reflected XSS in API responses."""
        for param in self._get_injectable_params(ep):
            for payload in PayloadDB.XSS_PAYLOADS[:8]:
                resp = self._inject_param(ep, param.name, payload, param.location)
                if not resp:
                    continue
                if payload in resp.text:
                    ct = resp.headers.get("Content-Type", "").lower()
                    severity = "HIGH" if "html" in ct else "MEDIUM"
                    self._add_finding(
                        "INJ-XSS", severity, ep, payload, param.name, resp,
                        "Cross-site scripting (reflected)",
                        f"Payload reflected in response (Content-Type: {ct}).",
                        cvss=6.1 if severity == "MEDIUM" else 7.5,
                    )
                    return

    # ---- Server-Side Template Injection ----

    def _test_ssti(self, ep: APIEndpoint):
        """Test for SSTI by injecting template expressions."""
        detection_pairs = [
            ("{{7*7}}", "49"),
            ("${7*7}", "49"),
            ("#{7*7}", "49"),
            ("<%= 7*7 %>", "49"),
        ]
        for param in self._get_injectable_params(ep):
            for payload, expected in detection_pairs:
                resp = self._inject_param(ep, param.name, payload, param.location)
                if resp and expected in resp.text and payload not in resp.text:
                    self._add_finding(
                        "INJ-SSTI", "CRITICAL", ep, payload, param.name, resp,
                        "Server-side template injection",
                        f"Template expression '{payload}' evaluated to '{expected}'.",
                        cvss=9.8,
                    )
                    return

    # ---- Command Injection ----

    def _test_cmdi(self, ep: APIEndpoint):
        """Test for OS command injection."""
        for param in self._get_injectable_params(ep):
            # Time-based detection (safe)
            time_payloads = ["; sleep 3", "| sleep 3", "$(sleep 3)", "`sleep 3`"]
            for payload in time_payloads:
                start = time.monotonic()
                resp = self._inject_param(ep, param.name, payload, param.location)
                elapsed = time.monotonic() - start
                if elapsed >= 2.5:
                    self._add_finding(
                        "INJ-CMDI", "CRITICAL", ep, payload, param.name, resp,
                        "OS command injection (time-based)",
                        f"sleep command caused {elapsed:.1f}s delay.",
                        cvss=9.8,
                    )
                    return

            # Error/output-based
            for payload in PayloadDB.CMDI_PAYLOADS[:5]:
                resp = self._inject_param(ep, param.name, payload, param.location)
                if resp and any(s in resp.text for s in ["uid=", "root:", "/bin/"]):
                    self._add_finding(
                        "INJ-CMDI", "CRITICAL", ep, payload, param.name, resp,
                        "OS command injection",
                        "Command output detected in response.",
                        cvss=9.8,
                    )
                    return

    # ---- XXE ----

    def _test_xxe(self, ep: APIEndpoint):
        """Test for XML External Entity injection."""
        for payload in PayloadDB.XXE_PAYLOADS[:3]:
            resp = self.client.request(
                ep.method, ep.full_url,
                raw_body=payload,
                headers={"Content-Type": "application/xml"},
            )
            if resp and any(s in resp.text for s in ["root:", "nobody:", "daemon:"]):
                self._add_finding(
                    "INJ-XXE", "CRITICAL", ep, payload[:100], "body", resp,
                    "XML External Entity injection",
                    "File contents (e.g., /etc/passwd) returned via XXE.",
                    cvss=9.1,
                )
                return
            # OOB detection would require a collaborator — log for manual review
            if resp and resp.status_code == 200 and "xml" in resp.headers.get("Content-Type", "").lower():
                logger.debug(f"XXE: XML accepted at {ep.full_url} — manual OOB testing recommended.")

    # ---- Path Traversal ----

    def _test_path_traversal(self, ep: APIEndpoint):
        """Test for path traversal in parameters."""
        file_params = [p for p in ep.parameters
                       if any(k in p.name.lower() for k in ["file", "path", "name", "doc", "page", "dir", "folder"])]

        for param in file_params:
            for payload in PayloadDB.PATH_TRAVERSAL_PAYLOADS[:8]:
                resp = self._inject_param(ep, param.name, payload, param.location)
                if resp and any(s in resp.text for s in ["root:", "nobody:", "[extensions]", "[boot loader]"]):
                    self._add_finding(
                        "INJ-TRAVERSAL", "HIGH", ep, payload, param.name, resp,
                        "Path traversal",
                        "File contents returned via directory traversal.",
                        cvss=7.5,
                    )
                    return

    # ---- Helpers ----

    def _get_injectable_params(self, ep: APIEndpoint) -> list:
        """Get parameters suitable for injection testing."""
        return [p for p in ep.parameters if p.location in ("query", "path")]

    def _get_body_fields(self, ep: APIEndpoint) -> list:
        """Get body field names from schema."""
        if ep.request_body_schema:
            return list(ep.request_body_schema.get("properties", {}).keys())[:5]
        return ["username", "email", "name", "query", "search", "input"]

    def _inject_param(self, ep, param_name: str, payload, location: str):
        """Inject payload into the appropriate request location."""
        if location == "query":
            return self.client.request(ep.method, ep.full_url, params={param_name: payload})
        elif location == "path":
            url = ep.full_url.replace(f"{{{param_name}}}", str(payload))
            return self.client.request(ep.method, url)
        else:
            return self.client.request(ep.method, ep.full_url, json_body={param_name: payload})

    def _add_finding(self, check_id, severity, ep, payload, param, resp, title, evidence, cvss=0.0):
        """Create and store an injection finding."""
        self.findings.append(Finding(
            check_id=check_id,
            severity=severity,
            title=f"{title} — {ep.path} [{param}]",
            description=f"{title} detected in parameter '{param}' of {ep.method} {ep.path}.",
            endpoint=ep.full_url,
            method=ep.method,
            evidence=f"Param: {param}, Payload: {payload[:200]}\n{evidence}",
            request_raw=self.client.build_raw_request(ep.method, ep.full_url, self.config.get_headers(), str(payload)[:500]),
            response_raw=self.client.build_raw_response(resp) if resp else "",
            response_code=resp.status_code if resp else 0,
            confidence="Medium",
            remediation="Use parameterized queries/prepared statements. Validate and sanitize all input.",
            references=[self.OWASP_REF],
            cvss=cvss,
            tags=["injection", check_id.lower().replace("inj-", "")],
        ))
