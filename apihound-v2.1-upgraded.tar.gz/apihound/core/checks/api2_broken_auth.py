"""
APIHound — API2:2023 Broken Authentication
Tests for weak auth, JWT issues, credential stuffing, missing rate limits on auth.
"""
import base64
import json
import logging
import re
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api2")


class BrokenAuthCheck:
    """Test for authentication weaknesses across API endpoints."""

    CHECK_ID = "API2-AUTH"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa2-broken-authentication/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting authentication checks")

        # Phase 1: Test unauthenticated access to all endpoints
        self._test_unauth_access(endpoints)

        # Phase 2: Find login endpoints and test weak creds
        login_eps = self._find_auth_endpoints(endpoints)
        for ep in login_eps:
            self._test_weak_credentials(ep)
            self._test_auth_rate_limiting(ep)

        # Phase 3: JWT analysis (if auth header contains JWT)
        if self.config.auth_header and "." in self.config.auth_header:
            self._test_jwt_none_algorithm(endpoints)
            self._test_jwt_missing_signature(endpoints)

        # Phase 4: Auth bypass headers
        self._test_auth_bypass_headers(endpoints)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_unauth_access(self, endpoints: List[APIEndpoint]):
        """Send requests without any authentication."""
        for ep in endpoints[:50]:  # Cap to avoid excessive testing
            headers = {
                "User-Agent": "APIHound/2.0",
                "Accept": "application/json",
            }
            resp = self.client.request(ep.method, ep.full_url, headers=headers)
            if resp and resp.status_code == 200 and len(resp.text) > 20:
                # Check if this endpoint should require auth
                auth_indicators = ep.security or any(
                    k in ep.path.lower() for k in ["user", "account", "profile", "admin", "private"]
                )
                if auth_indicators:
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="HIGH",
                        title=f"Unauthenticated access — {ep.path}",
                        description="Endpoint returns data without authentication despite appearing to require it.",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence=f"200 OK with {len(resp.text)} bytes without auth token.",
                        response_code=resp.status_code,
                        confidence="Medium",
                        remediation="Enforce authentication on all sensitive endpoints.",
                        references=[self.OWASP_REF],
                        cvss=7.5,
                        tags=["auth", "unauthenticated"],
                    ))

    def _find_auth_endpoints(self, endpoints: List[APIEndpoint]) -> List[APIEndpoint]:
        """Identify login/registration/token endpoints."""
        auth_patterns = ["login", "signin", "auth", "token", "session", "register", "signup"]
        return [ep for ep in endpoints
                if any(p in ep.path.lower() for p in auth_patterns) and ep.method in ("POST", "PUT")]

    def _test_weak_credentials(self, ep: APIEndpoint):
        """Test default/weak credentials against login endpoint."""
        creds = PayloadDB.BROKEN_AUTH_PAYLOADS["weak_credentials"][:10]

        for username, password in creds:
            bodies = [
                {"username": username, "password": password},
                {"email": f"{username}@test.com", "password": password},
                {"user": username, "pass": password},
            ]
            for body in bodies:
                resp = self.client.post(ep.full_url, json_body=body)
                if resp and resp.status_code == 200:
                    try:
                        data = resp.json()
                        # Check for token in response (successful login)
                        if any(k in str(data).lower() for k in ["token", "jwt", "session", "access"]):
                            self.findings.append(Finding(
                                check_id=self.CHECK_ID,
                                severity="CRITICAL",
                                title=f"Weak credentials accepted — {ep.path}",
                                description=f"Login succeeded with weak credentials: {username}:{password}",
                                endpoint=ep.full_url,
                                method="POST",
                                evidence=f"Login response contained auth token for {username}:{password}",
                                response_code=200,
                                confidence="High",
                                remediation="Enforce strong password policies. Block default credentials.",
                                references=[self.OWASP_REF],
                                cvss=9.1,
                                tags=["auth", "weak-credentials", "default-password"],
                            ))
                            return  # Found one, stop testing this endpoint
                    except (json.JSONDecodeError, ValueError):
                        pass

    def _test_auth_rate_limiting(self, ep: APIEndpoint):
        """Check if auth endpoint has rate limiting."""
        body = {"username": "ratelimitcheck", "password": "wrongpass123"}
        success_count = 0

        for _ in range(15):
            resp = self.client.post(ep.full_url, json_body=body)
            if resp and resp.status_code in (200, 401, 403):
                success_count += 1
            elif resp and resp.status_code == 429:
                return  # Rate limiting is working

        if success_count >= 14:
            self.findings.append(Finding(
                check_id=self.CHECK_ID,
                severity="MEDIUM",
                title=f"No rate limiting on auth endpoint — {ep.path}",
                description="Authentication endpoint allows unlimited login attempts without rate limiting.",
                endpoint=ep.full_url,
                method="POST",
                evidence=f"Sent 15 requests without receiving 429 (got {success_count} responses).",
                confidence="High",
                remediation="Implement rate limiting on authentication endpoints (e.g., 5 attempts per minute).",
                references=[self.OWASP_REF],
                cvss=5.3,
                tags=["auth", "rate-limiting", "brute-force"],
            ))

    def _test_jwt_none_algorithm(self, endpoints: List[APIEndpoint]):
        """Test JWT 'none' algorithm bypass."""
        auth = self.config.auth_header
        # Extract JWT token
        token = auth.replace("Bearer ", "").strip()
        parts = token.split(".")
        if len(parts) != 3:
            return

        # Decode payload
        try:
            payload_b64 = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        except Exception:
            return

        # Build none-algorithm tokens
        for none_header_b64 in PayloadDB.BROKEN_AUTH_PAYLOADS["jwt_none_algorithm"]:
            forged = f"{none_header_b64}.{parts[1]}."
            test_headers = {"Authorization": f"Bearer {forged}"}

            for ep in endpoints[:5]:
                resp = self.client.request(ep.method, ep.full_url, headers=test_headers)
                if resp and resp.status_code == 200 and len(resp.text) > 20:
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="CRITICAL",
                        title="JWT 'none' algorithm accepted",
                        description="API accepts JWT tokens with 'none' algorithm, allowing signature bypass.",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence="Forged JWT with alg:none was accepted and returned valid data.",
                        response_code=200,
                        confidence="High",
                        remediation="Reject JWT tokens with 'none' algorithm. Validate algorithm server-side.",
                        references=[self.OWASP_REF],
                        cvss=9.8,
                        tags=["auth", "jwt", "none-algorithm"],
                    ))
                    return

    def _test_jwt_missing_signature(self, endpoints: List[APIEndpoint]):
        """Test if API accepts JWT with empty/truncated signature."""
        auth = self.config.auth_header
        token = auth.replace("Bearer ", "").strip()
        parts = token.split(".")
        if len(parts) != 3:
            return

        # Token with empty signature
        truncated = f"{parts[0]}.{parts[1]}."
        test_headers = {"Authorization": f"Bearer {truncated}"}

        for ep in endpoints[:3]:
            resp = self.client.request(ep.method, ep.full_url, headers=test_headers)
            if resp and resp.status_code == 200:
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="CRITICAL",
                    title="JWT accepted without signature",
                    description="API accepts JWT tokens with missing/empty signature.",
                    endpoint=ep.full_url,
                    method=ep.method,
                    evidence="JWT with empty signature field was accepted.",
                    response_code=200,
                    confidence="High",
                    remediation="Always validate JWT signatures. Reject tokens with missing signatures.",
                    references=[self.OWASP_REF],
                    cvss=9.8,
                    tags=["auth", "jwt", "no-signature"],
                ))
                return

    def _test_auth_bypass_headers(self, endpoints: List[APIEndpoint]):
        """Test if auth can be bypassed using special headers."""
        bypass_headers_list = PayloadDB.BROKEN_AUTH_PAYLOADS["auth_bypass_headers"]

        for ep in endpoints[:10]:
            # Get baseline (should be 401/403 without auth)
            no_auth_headers = {"User-Agent": "APIHound/2.0", "Accept": "application/json"}
            baseline = self.client.request(ep.method, ep.full_url, headers=no_auth_headers)
            if not baseline or baseline.status_code == 200:
                continue  # Already accessible or unreachable

            for bypass_h in bypass_headers_list[:5]:
                test_headers = {**no_auth_headers, **bypass_h}
                resp = self.client.request(ep.method, ep.full_url, headers=test_headers)
                if resp and resp.status_code == 200 and baseline.status_code in (401, 403):
                    header_name = list(bypass_h.keys())[0]
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="HIGH",
                        title=f"Auth bypass via {header_name} — {ep.path}",
                        description=f"Authentication bypassed using header: {header_name}",
                        endpoint=ep.full_url,
                        method=ep.method,
                        evidence=f"Header {bypass_h} changed response from {baseline.status_code} to 200.",
                        response_code=200,
                        confidence="High",
                        remediation="Do not rely on client-supplied headers for authentication or authorization.",
                        references=[self.OWASP_REF],
                        cvss=8.2,
                        tags=["auth", "bypass", "header-injection"],
                    ))
                    break
