"""APIHound — Vulnerability check modules (OWASP API Security Top 10 2023)."""

from core.checks.api1_bola import BOLACheck
from core.checks.api2_broken_auth import BrokenAuthCheck
from core.checks.api3_property_auth import PropertyAuthCheck
from core.checks.api4_resource_consumption import ResourceConsumptionCheck
from core.checks.api5_function_auth import FunctionAuthCheck
from core.checks.api6_business_flow import BusinessFlowCheck
from core.checks.api7_ssrf import SSRFCheck
from core.checks.api8_misconfig import MisconfigCheck
from core.checks.api9_inventory import InventoryCheck
from core.checks.api10_unsafe_consumption import UnsafeConsumptionCheck
from core.checks.injection import InjectionCheck
from core.checks.jwt_attacks import JWTAttackCheck

ALL_CHECKS = {
    "api1": BOLACheck,
    "api2": BrokenAuthCheck,
    "api3": PropertyAuthCheck,
    "api4": ResourceConsumptionCheck,
    "api5": FunctionAuthCheck,
    "api6": BusinessFlowCheck,
    "api7": SSRFCheck,
    "api8": MisconfigCheck,
    "api9": InventoryCheck,
    "api10": UnsafeConsumptionCheck,
    "injection": InjectionCheck,
    "jwt": JWTAttackCheck,
}
