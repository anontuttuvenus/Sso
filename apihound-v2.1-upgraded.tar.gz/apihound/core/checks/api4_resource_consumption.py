"""
APIHound — API4:2023 Unrestricted Resource Consumption
Tests for missing rate limits, pagination abuse, large payload DoS.
"""
import logging
import time
from typing import List
from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api4")


class ResourceConsumptionCheck:
    CHECK_ID = "API4-RESOURCE"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa4-unrestricted-resource-consumption/"

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        logger.info(f"[{self.CHECK_ID}] Starting resource consumption checks")

        for ep in endpoints[:30]:
            self._test_missing_rate_limit(ep)
            self._test_pagination_abuse(ep)

        for ep in endpoints[:10]:
            if ep.method in ("POST", "PUT", "PATCH"):
                self._test_large_payload(ep)

        logger.info(f"[{self.CHECK_ID}] Complete: {len(self.findings)} findings")
        return self.findings

    def _test_missing_rate_limit(self, ep: APIEndpoint):
        """Check if endpoint enforces rate limiting."""
        success_count = 0
        start = time.monotonic()

        for _ in range(20):
            resp = self.client.request(ep.method, ep.full_url)
            if resp and resp.status_code != 429:
                success_count += 1
            elif resp and resp.status_code == 429:
                return  # Rate limiting works

        elapsed = time.monotonic() - start
        if success_count >= 18:
            self.findings.append(Finding(
                check_id=self.CHECK_ID,
                severity="MEDIUM",
                title=f"No rate limiting — {ep.path}",
                description="Endpoint does not enforce rate limiting, allowing unrestricted request volume.",
                endpoint=ep.full_url,
                method=ep.method,
                evidence=f"Sent 20 requests in {elapsed:.1f}s, all accepted (no 429 responses).",
                confidence="High",
                remediation="Implement rate limiting per client/IP. Use HTTP 429 with Retry-After header.",
                references=[self.OWASP_REF],
                cvss=4.3,
                tags=["rate-limiting", "dos"],
            ))

    def _test_pagination_abuse(self, ep: APIEndpoint):
        """Test if API allows excessively large page sizes."""
        pagination_params = PayloadDB.RESOURCE_CONSUMPTION_PAYLOADS["large_pagination"]

        for params in pagination_params[:3]:
            resp = self.client.get(ep.full_url, params=params)
            if resp and resp.status_code == 200:
                body_size = len(resp.text)
                if body_size > 100_000:  # 100KB+ response
                    self.findings.append(Finding(
                        check_id=self.CHECK_ID,
                        severity="MEDIUM",
                        title=f"Unrestricted pagination — {ep.path}",
                        description="API allows extremely large page sizes, risking resource exhaustion.",
                        endpoint=ep.full_url,
                        method="GET",
                        evidence=f"Params {params} returned {body_size:,} bytes.",
                        response_code=200,
                        confidence="High",
                        remediation="Enforce maximum page size server-side. Cap limit/per_page to a reasonable value (e.g., 100).",
                        references=[self.OWASP_REF],
                        cvss=5.3,
                        tags=["pagination", "dos", "resource-consumption"],
                    ))
                    return

    def _test_large_payload(self, ep: APIEndpoint):
        """Test if API accepts oversized request payloads."""
        # Deep nesting test
        deep_json = PayloadDB.RESOURCE_CONSUMPTION_PAYLOADS["deep_json_nesting"](30)
        resp = self.client.request(
            ep.method, ep.full_url,
            raw_body=deep_json,
            headers={"Content-Type": "application/json"},
        )
        if resp and resp.status_code in (200, 201, 500):
            if resp.status_code == 500:
                self.findings.append(Finding(
                    check_id=self.CHECK_ID,
                    severity="MEDIUM",
                    title=f"Deep JSON nesting causes server error — {ep.path}",
                    description="Deeply nested JSON payload caused a 500 error, indicating potential DoS vector.",
                    endpoint=ep.full_url,
                    method=ep.method,
                    evidence="30-level deep JSON nesting triggered server error.",
                    response_code=500,
                    confidence="Medium",
                    remediation="Set maximum JSON nesting depth. Validate payload structure before processing.",
                    references=[self.OWASP_REF],
                    cvss=5.3,
                    tags=["dos", "json-nesting"],
                ))
