"""API1:2023 Broken Object Level Authorization (BOLA).

Detection is intentionally differential: a successful response is not enough on
its own.  APIHound compares a known-object baseline with an alternate object and
raises confidence only when the alternate object is explicitly supplied by the
operator or the response contains strong object-specific evidence.
"""
from __future__ import annotations

import json
import logging
import re
from typing import List

from core.config import Finding, ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint
from core.response_analysis import materially_different, similarity
from payloads.payload_db import PayloadDB

logger = logging.getLogger("apihound.checks.api1")


class BOLACheck:
    CHECK_ID = "API1-BOLA"
    SEVERITY = "HIGH"
    OWASP_REF = "https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/"
    _ID_HINTS = ("id", "uid", "uuid", "pk", "user", "account", "order", "member", "customer")

    def __init__(self, config: ScanConfig, client: HTTPClient):
        self.config = config
        self.client = client
        self.findings: List[Finding] = []

    def run(self, endpoints: List[APIEndpoint]) -> List[Finding]:
        candidates = [ep for ep in endpoints if ep.has_id_params()]
        logger.info("[%s] %d BOLA candidates", self.CHECK_ID, len(candidates))
        for ep in candidates:
            # Keep automatic object enumeration read-only. Mutation BOLA tests need
            # explicit fixtures and are better performed manually or in lab mode.
            if ep.method not in ("GET", "HEAD") and not self.config.lab_mode:
                continue
            self._test_path_ids(ep)
            self._test_query_ids(ep)
        return self.findings

    def _baseline(self, ep: APIEndpoint, path_value=None, query_name=None, query_value=None):
        url, params, headers, body = self.client.request_builder.build(ep)
        if path_value is not None:
            url = self._replace_id_placeholder(url, path_value, ep)
        if query_name is not None:
            params[query_name] = query_value
        return url, self.client.request(ep.method, url, params=params, headers=headers, json_body=body)

    def _replace_id_placeholder(self, url: str, value, ep: APIEndpoint) -> str:
        id_names = [p.name for p in ep.parameters if p.location == "path" and self._is_id_name(p.name)]
        if id_names:
            for name in id_names:
                # RequestBuilder has already materialized placeholders. Rebuild from
                # the endpoint template so we can select the object deterministically.
                template = ep.full_url
                u, params, headers, body = self.client.request_builder.build(ep)
                template = ep.full_url
                for p in ep.parameters:
                    if p.location == "path":
                        v = value if p.name == name else self.client.request_builder._sample_value(p)
                        template = template.replace("{" + p.name + "}", str(v))
                for leftover in re.findall(r"\{([^{}]+)\}", template):
                    template = template.replace("{" + leftover + "}", str(value if self._is_id_name(leftover) else "test"))
                return template
        return re.sub(r"\{[^}]*id[^}]*\}", str(value), ep.full_url, flags=re.I)

    @classmethod
    def _is_id_name(cls, name: str) -> bool:
        n = name.lower()
        return any(h in n for h in cls._ID_HINTS)

    def _test_path_ids(self, ep: APIEndpoint):
        path_ids = [p for p in ep.parameters if p.location == "path" and self._is_id_name(p.name)]
        if not path_ids and not re.search(r"\{[^}]*id[^}]*\}", ep.path, re.I):
            return

        baseline_value = self.config.user_id or None
        baseline_url, baseline = self._baseline(ep, path_value=baseline_value) if baseline_value else self._baseline(ep)
        if not baseline or baseline.status_code not in range(200, 300):
            return

        candidates = []
        if self.config.user_id_other:
            candidates.append((self.config.user_id_other, "High"))
        if self.config.lab_mode:
            candidates.extend((x, "Low") for x in PayloadDB.BOLA_ID_PAYLOADS["sequential_int"][:10])
        elif not candidates:
            # Production default: one low-noise adjacent-ID probe only for numeric IDs.
            if self.config.user_id and str(self.config.user_id).isdigit():
                candidates.append((str(int(self.config.user_id) + 1), "Medium"))
            else:
                return

        for test_id, confidence in candidates:
            test_url = self._replace_id_placeholder(ep.full_url, test_id, ep)
            if test_url == baseline_url:
                continue
            resp = self.client.request(ep.method, test_url)
            if not resp or resp.status_code not in range(200, 300):
                continue
            score = similarity(baseline, resp)
            if materially_different(baseline, resp, 0.90):
                self._report(ep, test_url, resp,
                    f"Alternate object '{test_id}' returned HTTP {resp.status_code}; normalized response similarity to baseline: {score:.2f}.",
                    confidence)
                return

    def _test_query_ids(self, ep: APIEndpoint):
        for p in [x for x in ep.parameters if x.location == "query" and self._is_id_name(x.name)]:
            baseline_value = self.config.user_id or self.client.request_builder._sample_value(p)
            baseline_url, baseline = self._baseline(ep, query_name=p.name, query_value=baseline_value)
            if not baseline or baseline.status_code not in range(200, 300):
                continue
            if self.config.user_id_other:
                candidates = [(self.config.user_id_other, "High")]
            elif self.config.lab_mode:
                candidates = [(x, "Low") for x in PayloadDB.BOLA_ID_PAYLOADS["sequential_int"][:5]]
            elif str(baseline_value).isdigit():
                candidates = [(str(int(baseline_value) + 1), "Medium")]
            else:
                continue
            for test_id, confidence in candidates:
                url, params, headers, body = self.client.request_builder.build(ep)
                params[p.name] = test_id
                resp = self.client.request(ep.method, url, params=params, headers=headers, json_body=body)
                if resp and resp.status_code in range(200, 300) and materially_different(baseline, resp, 0.90):
                    self._report(ep, url, resp,
                        f"Changing query object reference {p.name}={test_id} returned a materially different successful object response.",
                        confidence)
                    return

    def _report(self, ep, url, resp, evidence, confidence):
        self.findings.append(Finding(
            check_id=self.CHECK_ID,
            severity=self.SEVERITY,
            title=f"Potential BOLA — {ep.path}",
            description="An alternate object reference returned a successful, materially different response under the same authenticated session.",
            endpoint=url,
            method=ep.method,
            evidence=evidence,
            request_raw=self.client.build_raw_request(ep.method, url, self.config.get_headers()),
            response_raw=self.client.build_raw_response(resp),
            response_code=resp.status_code,
            confidence=confidence,
            remediation="Enforce object-level authorization on every request using the authenticated principal and server-side ownership or access-control rules.",
            references=[self.OWASP_REF],
            cvss=7.5,
            tags=["bola", "idor", "authorization", "differential"],
        ))
