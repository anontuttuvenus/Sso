"""Scanner orchestrator."""
from __future__ import annotations

import logging
import time
from typing import List

from core.checks import ALL_CHECKS
from core.config import Finding, ScanConfig, SEVERITY_ORDER
from core.crawler import APICrawler
from core.http_client import HTTPClient
from core.openapi_parser import APIEndpoint, OpenAPIParser
from waf_bypass.waf_engine import WAFBypassEngine

logger = logging.getLogger("apihound.scanner")


class Scanner:
    def __init__(self, config: ScanConfig):
        self.config = config
        self.waf_engine = WAFBypassEngine() if config.waf_bypass else None
        self.client = HTTPClient(config, self.waf_engine)
        self.endpoints: List[APIEndpoint] = []
        self.findings: List[Finding] = []
        self.scan_start = 0.0
        self.scan_duration = 0.0
        self.duplicates_removed = 0

    def run(self) -> List[Finding]:
        self.scan_start = time.time()
        logger.info("=" * 60)
        logger.info("APIHound v2.1 — OWASP API Security Scanner")
        logger.info("=" * 60)
        self._discover_endpoints()
        if not self.endpoints:
            logger.error("No endpoints discovered. Provide --spec or --target with --crawl.")
            return []
        if self.config.max_endpoints > 0:
            self.endpoints = self.endpoints[: self.config.max_endpoints]
        logger.info("Total endpoints to test: %d", len(self.endpoints))

        selected = self._resolve_checks()
        logger.info("Running checks: %s", list(selected.keys()))
        for check_id, check_cls in selected.items():
            try:
                logger.info("--- Running %s ---", check_id)
                check = check_cls(self.config, self.client)
                results = check.run(self.endpoints)
                self.findings.extend(results)
                logger.info("--- %s: %d findings ---", check_id, len(results))
            except Exception as exc:
                logger.error("Check %s failed: %s", check_id, exc, exc_info=True)

        self._deduplicate_findings()
        self.findings.sort(key=lambda f: (SEVERITY_ORDER.get(f.severity, 99), f.check_id, f.endpoint))
        self.scan_duration = time.time() - self.scan_start
        logger.info("Scan complete in %.1fs; %d findings (%d duplicates removed)", self.scan_duration, len(self.findings), self.duplicates_removed)
        self._print_summary()
        return self.findings

    def _discover_endpoints(self):
        if self.config.spec_path:
            parser = OpenAPIParser(self.config.target_url)
            spec_data = self._load_spec()
            if spec_data:
                self.endpoints.extend(parser.parse(spec_data))
                if not self.config.target_url and parser.base_url:
                    self.config.target_url = parser.base_url
        if self.config.crawl and self.config.target_url:
            crawler = APICrawler(self.config, self.client)
            self.endpoints.extend(crawler.crawl(self.config.target_url))

        base = self.config.target_url.rstrip("/") if self.config.target_url else ""
        unique = {}
        for ep in self.endpoints:
            if not ep.full_url and base:
                ep.full_url = f"{base}{ep.path}"
            key = (ep.method.upper(), ep.path.rstrip("/") or "/")
            # Prefer spec-derived metadata over crawler stubs.
            current = unique.get(key)
            if current is None or len(ep.parameters) + bool(ep.request_body_schema) > len(current.parameters) + bool(current.request_body_schema):
                unique[key] = ep
        self.endpoints = list(unique.values())

    def _load_spec(self) -> str:
        path = self.config.spec_path
        if path.startswith(("http://", "https://")):
            resp = self.client.get(path)
            return resp.text if resp else ""
        try:
            with open(path, encoding="utf-8") as f:
                return f.read()
        except (FileNotFoundError, OSError) as exc:
            logger.error("Unable to read spec %s: %s", path, exc)
            return ""

    def _resolve_checks(self) -> dict:
        if "all" in self.config.checks:
            return dict(ALL_CHECKS)
        selected = {}
        for check_id in self.config.checks:
            key = check_id.strip().lower()
            if key in ALL_CHECKS:
                selected[key] = ALL_CHECKS[key]
            else:
                logger.warning("Unknown check: %s", key)
        return selected

    def _deduplicate_findings(self):
        unique = {}
        for finding in self.findings:
            key = (
                finding.check_id,
                finding.method.upper(),
                finding.endpoint.split("?", 1)[0].rstrip("/"),
                finding.title,
            )
            if key not in unique:
                unique[key] = finding
            else:
                old = unique[key]
                confidence_rank = {"High": 3, "Medium": 2, "Low": 1}
                if confidence_rank.get(finding.confidence, 0) > confidence_rank.get(old.confidence, 0):
                    unique[key] = finding
        self.duplicates_removed = len(self.findings) - len(unique)
        self.findings = list(unique.values())

    def _print_summary(self):
        counts = {}
        for f in self.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
            if counts.get(sev):
                logger.info("  %s: %d", sev, counts[sev])

    def get_scan_metadata(self) -> dict:
        stats = self.client.stats
        return {
            "version": "2.1.0",
            "target": self.config.target_url,
            "spec": self.config.spec_path,
            "endpoints_tested": len(self.endpoints),
            "total_findings": len(self.findings),
            "duplicates_removed": self.duplicates_removed,
            "scan_duration_seconds": round(self.scan_duration, 1),
            "checks_run": self.config.checks,
            "waf_bypass": self.config.waf_bypass,
            "requests_sent": stats.get("requests", 0),
            "request_errors": stats.get("errors", 0),
            "retries": stats.get("retries", 0),
            "bytes_received": stats.get("bytes_received", 0),
            "waf_blocks": stats.get("waf_blocks", 0),
        }

    def close(self):
        self.client.close()
