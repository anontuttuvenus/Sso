"""Report generator: HTML, JSON and SARIF 2.1.0."""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import List
from urllib.parse import urlsplit, urlunsplit

from jinja2 import Environment, FileSystemLoader
from core.config import Finding

logger = logging.getLogger("apihound.reporter")
_TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates")


class Reporter:
    def __init__(self, output_dir: str = "reports"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def generate(self, findings: List[Finding], metadata: dict, formats: List[str] = None) -> List[str]:
        formats = [f.lower() for f in (formats or ["html", "json"])]
        outputs = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if "json" in formats:
            outputs.append(self._generate_json(findings, metadata, timestamp))
        if "html" in formats:
            outputs.append(self._generate_html(findings, metadata, timestamp))
        if "sarif" in formats:
            outputs.append(self._generate_sarif(findings, metadata, timestamp))
        return outputs

    def _generate_json(self, findings, metadata, timestamp):
        report = {"metadata": metadata, "scan_date": datetime.now().isoformat(), "summary": self._build_summary(findings), "findings": [f.to_dict() for f in findings]}
        path = os.path.join(self.output_dir, f"apihound_report_{timestamp}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, default=str, ensure_ascii=False)
        logger.info("JSON report: %s", path)
        return path

    def _generate_html(self, findings, metadata, timestamp):
        env = Environment(loader=FileSystemLoader(_TEMPLATE_DIR), autoescape=True)
        template = env.get_template("report.html")
        html = template.render(meta=metadata, counts=self._build_summary(findings), findings=[f.to_dict() for f in findings], scan_date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        path = os.path.join(self.output_dir, f"apihound_report_{timestamp}.html")
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        logger.info("HTML report: %s", path)
        return path

    def _generate_sarif(self, findings, metadata, timestamp):
        level = {"CRITICAL": "error", "HIGH": "error", "MEDIUM": "warning", "LOW": "note", "INFO": "note"}
        rules = {}
        results = []
        for finding in findings:
            rules.setdefault(finding.check_id, {
                "id": finding.check_id,
                "name": finding.check_id.replace("-", "_"),
                "shortDescription": {"text": finding.title},
                "help": {"text": finding.remediation or finding.description},
                "helpUri": finding.references[0] if finding.references else "https://owasp.org/API-Security/",
            })
            uri = self._strip_query(finding.endpoint)
            results.append({
                "ruleId": finding.check_id,
                "level": level.get(finding.severity, "warning"),
                "message": {"text": f"{finding.title}: {finding.description}"},
                "locations": [{"physicalLocation": {"artifactLocation": {"uri": uri}}}],
                "properties": {"severity": finding.severity, "confidence": finding.confidence, "httpMethod": finding.method, "cvss": finding.cvss},
            })
        sarif = {
            "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
            "version": "2.1.0",
            "runs": [{"tool": {"driver": {"name": "APIHound", "version": metadata.get("version", "2.1.0"), "informationUri": "https://owasp.org/API-Security/", "rules": list(rules.values())}}, "results": results}],
        }
        path = os.path.join(self.output_dir, f"apihound_report_{timestamp}.sarif")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(sarif, f, indent=2, ensure_ascii=False)
        logger.info("SARIF report: %s", path)
        return path

    @staticmethod
    def _strip_query(url: str) -> str:
        try:
            p = urlsplit(url)
            return urlunsplit((p.scheme, p.netloc, p.path, "", ""))
        except Exception:
            return url.split("?", 1)[0]

    @staticmethod
    def _build_summary(findings):
        counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for f in findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        return counts
