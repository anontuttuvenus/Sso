"""OpenAPI / Swagger parser with local $ref resolution and request examples."""
from __future__ import annotations

import copy
import json
import logging
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urljoin

import yaml

logger = logging.getLogger("apihound.parser")


@dataclass
class APIParameter:
    name: str
    location: str
    param_type: str = "string"
    format: str = ""
    required: bool = False
    example: Any = ""
    enum: list = field(default_factory=list)
    schema: dict = field(default_factory=dict)


@dataclass
class APIEndpoint:
    path: str
    method: str
    full_url: str = ""
    summary: str = ""
    operation_id: str = ""
    parameters: list = field(default_factory=list)
    request_body_schema: dict = field(default_factory=dict)
    request_body_example: Any = None
    response_schemas: dict = field(default_factory=dict)
    security: list = field(default_factory=list)
    tags: list = field(default_factory=list)
    content_type: str = "application/json"

    def has_path_params(self) -> bool:
        return "{" in self.path

    def has_id_params(self) -> bool:
        id_patterns = ["id", "uid", "user_id", "userid", "account_id", "order_id",
                       "item_id", "resource_id", "uuid", "pk", "slug"]
        for p in self.parameters:
            n = p.name.lower()
            if n in id_patterns or any(n.endswith(x) for x in ("_id", "id")):
                return True
        return any(x in self.path.lower() for x in ["{id", "{user", "{account", "{order", "{uuid"])


class OpenAPIParser:
    """Parse OpenAPI 2.0 and 3.x specifications.

    Supports local component references, path-level parameters, operation-level
    server overrides, examples/defaults, and Swagger 2 response schemas.
    """

    HTTP_METHODS = {"get", "post", "put", "delete", "patch", "head", "options", "trace"}

    def __init__(self, base_url: str = ""):
        self.base_url = base_url.rstrip("/")
        self.endpoints = []
        self.security_schemes = {}
        self.servers = []
        self.schemas = {}
        self._spec = {}

    def parse(self, spec_data: str) -> list:
        self.endpoints = []
        try:
            spec = json.loads(spec_data)
        except (json.JSONDecodeError, ValueError):
            spec = yaml.safe_load(spec_data)
        if not isinstance(spec, dict):
            logger.error("Invalid spec format")
            return []
        self._spec = spec
        if str(spec.get("openapi", "")).startswith("3"):
            return self._parse_openapi3(spec)
        if str(spec.get("swagger", "")).startswith("2"):
            return self._parse_swagger2(spec)
        logger.warning("Unknown spec version; attempting OpenAPI 3 parsing")
        return self._parse_openapi3(spec)

    def parse_file(self, path: str) -> list:
        with open(path, encoding="utf-8") as f:
            return self.parse(f.read())

    def _resolve_ref(self, value: Any, seen=None) -> Any:
        if not isinstance(value, dict) or "$ref" not in value:
            return value
        ref = value["$ref"]
        if not isinstance(ref, str) or not ref.startswith("#/"):
            return value  # external refs intentionally left unresolved
        seen = set(seen or ())
        if ref in seen:
            return value
        seen.add(ref)
        cur: Any = self._spec
        try:
            for part in ref[2:].split("/"):
                part = part.replace("~1", "/").replace("~0", "~")
                cur = cur[part]
        except (KeyError, TypeError):
            logger.debug("Unresolved local ref: %s", ref)
            return value
        resolved = copy.deepcopy(cur)
        if isinstance(resolved, dict) and "$ref" in resolved:
            resolved = self._resolve_ref(resolved, seen)
        if isinstance(resolved, dict):
            overlay = {k: copy.deepcopy(v) for k, v in value.items() if k != "$ref"}
            resolved.update(overlay)
        return resolved

    def _deep_resolve_schema(self, schema: Any, depth=0) -> Any:
        if depth > 12:
            return schema
        schema = self._resolve_ref(schema)
        if isinstance(schema, dict):
            return {k: self._deep_resolve_schema(v, depth + 1) for k, v in schema.items()}
        if isinstance(schema, list):
            return [self._deep_resolve_schema(v, depth + 1) for v in schema]
        return schema

    @staticmethod
    def _server_url(server: dict) -> str:
        url = str(server.get("url", ""))
        for name, info in server.get("variables", {}).items():
            url = url.replace("{" + name + "}", str(info.get("default", "")))
        return url.rstrip("/")

    def _parse_openapi3(self, spec: dict) -> list:
        self.servers = [self._server_url(s) for s in spec.get("servers", []) if isinstance(s, dict)]
        if not self.base_url and self.servers:
            self.base_url = self.servers[0]
        components = spec.get("components", {})
        self.security_schemes = components.get("securitySchemes", {})
        self.schemas = components.get("schemas", {})
        global_security = spec.get("security", [])

        for path, path_item in spec.get("paths", {}).items():
            path_item = self._resolve_ref(path_item)
            if not isinstance(path_item, dict):
                continue
            path_params = path_item.get("parameters", [])
            for method, details in path_item.items():
                if method.lower() not in self.HTTP_METHODS or not isinstance(details, dict):
                    continue
                ep = self._build_endpoint_v3(path, method, details, path_params, global_security)
                self.endpoints.append(ep)
        logger.info("Parsed %d endpoints from OpenAPI 3.x spec", len(self.endpoints))
        return self.endpoints

    def _parameter_v3(self, raw: dict) -> APIParameter:
        p = self._resolve_ref(raw)
        schema = self._deep_resolve_schema(p.get("schema", {}))
        example = p.get("example", schema.get("example", schema.get("default", "")))
        return APIParameter(
            name=p.get("name", ""), location=p.get("in", "query"),
            param_type=schema.get("type", "string"), format=schema.get("format", ""),
            required=p.get("required", False), example=example,
            enum=schema.get("enum", []), schema=schema,
        )

    def _build_endpoint_v3(self, path, method, details, path_params, global_security) -> APIEndpoint:
        server = ""
        if details.get("servers"):
            server = self._server_url(details["servers"][0])
        full_base = server or self.base_url
        ep = APIEndpoint(
            path=path, method=method.upper(), full_url=f"{full_base}{path}" if full_base else "",
            summary=str(details.get("summary", details.get("description", "")))[:200],
            operation_id=details.get("operationId", ""), tags=details.get("tags", []),
            security=details.get("security", global_security),
        )
        merged = []
        seen = set()
        for raw in list(path_params or []) + list(details.get("parameters", [])):
            p = self._parameter_v3(raw)
            key = (p.name, p.location)
            if key in seen:
                # operation-level parameter wins: replace previous
                merged = [x for x in merged if (x.name, x.location) != key]
            merged.append(p); seen.add(key)
        ep.parameters = merged

        req_body = self._resolve_ref(details.get("requestBody", {}))
        content = req_body.get("content", {}) if isinstance(req_body, dict) else {}
        if content:
            preferred = "application/json" if "application/json" in content else next(iter(content))
            ct_details = content[preferred]
            ep.content_type = preferred
            ep.request_body_schema = self._deep_resolve_schema(ct_details.get("schema", {}))
            ep.request_body_example = ct_details.get("example")
            if ep.request_body_example is None:
                examples = ct_details.get("examples", {})
                if examples:
                    first = self._resolve_ref(next(iter(examples.values())))
                    ep.request_body_example = first.get("value") if isinstance(first, dict) else None

        for code, raw_resp in details.get("responses", {}).items():
            resp = self._resolve_ref(raw_resp)
            for _, ct_details in (resp.get("content", {}) if isinstance(resp, dict) else {}).items():
                ep.response_schemas[str(code)] = self._deep_resolve_schema(ct_details.get("schema", {}))
                break
        return ep

    def _parse_swagger2(self, spec: dict) -> list:
        host = spec.get("host", "")
        base_path = spec.get("basePath", "")
        schemes = spec.get("schemes", ["https"])
        if not self.base_url and host:
            self.base_url = f"{schemes[0]}://{host}{base_path}".rstrip("/")
        self.security_schemes = spec.get("securityDefinitions", {})
        self.schemas = spec.get("definitions", {})
        global_security = spec.get("security", [])
        global_consumes = spec.get("consumes", ["application/json"])

        for path, path_item in spec.get("paths", {}).items():
            path_item = self._resolve_ref(path_item)
            if not isinstance(path_item, dict):
                continue
            path_params = path_item.get("parameters", [])
            for method, details in path_item.items():
                if method.lower() not in self.HTTP_METHODS or not isinstance(details, dict):
                    continue
                self.endpoints.append(self._build_endpoint_v2(path, method, details, path_params, global_security, global_consumes))
        logger.info("Parsed %d endpoints from Swagger 2.0 spec", len(self.endpoints))
        return self.endpoints

    def _build_endpoint_v2(self, path, method, details, path_params, global_security, global_consumes) -> APIEndpoint:
        ep = APIEndpoint(path=path, method=method.upper(), full_url=f"{self.base_url}{path}" if self.base_url else "",
            summary=str(details.get("summary", details.get("description", "")))[:200],
            operation_id=details.get("operationId", ""), tags=details.get("tags", []),
            security=details.get("security", global_security))
        seen = set()
        for raw in list(path_params or []) + list(details.get("parameters", [])):
            p = self._resolve_ref(raw)
            loc = p.get("in", "query")
            if loc == "body":
                ep.request_body_schema = self._deep_resolve_schema(p.get("schema", {}))
                continue
            schema = self._deep_resolve_schema(p.get("schema", {})) if loc == "body" else p
            param = APIParameter(name=p.get("name", ""), location=loc, param_type=p.get("type", "string"),
                format=p.get("format", ""), required=p.get("required", False),
                example=p.get("x-example", p.get("example", p.get("default", ""))), enum=p.get("enum", []), schema=schema)
            key=(param.name,param.location)
            if key in seen:
                ep.parameters=[x for x in ep.parameters if (x.name,x.location)!=key]
            ep.parameters.append(param); seen.add(key)
        consumes = details.get("consumes", global_consumes)
        if consumes:
            ep.content_type = consumes[0]
        for code, raw_resp in details.get("responses", {}).items():
            resp = self._resolve_ref(raw_resp)
            if isinstance(resp, dict) and "schema" in resp:
                ep.response_schemas[str(code)] = self._deep_resolve_schema(resp["schema"])
        return ep

    def get_bola_candidates(self) -> list:
        return [ep for ep in self.endpoints if ep.has_id_params()]

    def get_admin_candidates(self) -> list:
        patterns = ["admin", "manage", "config", "setting", "role", "permission", "system", "internal", "debug", "console", "dashboard"]
        return [ep for ep in self.endpoints if any(p in ep.path.lower() for p in patterns)]
