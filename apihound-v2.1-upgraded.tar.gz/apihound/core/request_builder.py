"""Build realistic requests from OpenAPI endpoint metadata.

This module keeps scan checks from sending unresolved ``{id}`` URLs or empty
bodies when the specification already contains enough information to construct
a valid baseline request.
"""
from __future__ import annotations

import re
from copy import deepcopy
from typing import Any, Dict, Tuple

from core.openapi_parser import APIEndpoint, APIParameter


class RequestBuilder:
    def __init__(self, path_overrides=None, query_overrides=None):
        self.path_overrides = path_overrides or {}
        self.query_overrides = query_overrides or {}

    @staticmethod
    def _sample_value(param: APIParameter) -> Any:
        if param.example not in (None, ""):
            return param.example
        if param.enum:
            return param.enum[0]
        fmt = (param.format or "").lower()
        typ = (param.param_type or "string").lower()
        name = param.name.lower()
        if fmt == "uuid" or "uuid" in name:
            return "00000000-0000-4000-8000-000000000001"
        if typ in ("integer", "number") or name.endswith("id") or name == "id":
            return 1
        if typ == "boolean":
            return True
        if fmt == "date":
            return "2026-01-01"
        if fmt in ("date-time", "datetime"):
            return "2026-01-01T00:00:00Z"
        if fmt == "email" or "email" in name:
            return "test@example.com"
        return "test"

    @classmethod
    def sample_from_schema(cls, schema: dict, depth: int = 0) -> Any:
        if not isinstance(schema, dict) or depth > 5:
            return {}
        if "example" in schema:
            return deepcopy(schema["example"])
        if "default" in schema:
            return deepcopy(schema["default"])
        enum = schema.get("enum") or []
        if enum:
            return deepcopy(enum[0])
        typ = schema.get("type")
        if not typ:
            if "properties" in schema:
                typ = "object"
            elif "items" in schema:
                typ = "array"
        if typ == "object":
            props = schema.get("properties", {})
            required = set(schema.get("required", []))
            result = {}
            for name, child in props.items():
                if name in required or "example" in child or "default" in child:
                    result[name] = cls.sample_from_schema(child, depth + 1)
            return result
        if typ == "array":
            return [cls.sample_from_schema(schema.get("items", {}), depth + 1)]
        if typ in ("integer", "number"):
            return schema.get("minimum", 1)
        if typ == "boolean":
            return True
        fmt = str(schema.get("format", "")).lower()
        if fmt == "uuid":
            return "00000000-0000-4000-8000-000000000001"
        if fmt == "email":
            return "test@example.com"
        if fmt == "date":
            return "2026-01-01"
        if fmt in ("date-time", "datetime"):
            return "2026-01-01T00:00:00Z"
        return "test"

    def build(self, ep: APIEndpoint) -> Tuple[str, Dict[str, Any], Dict[str, str], Any]:
        """Return ``(url, query, headers, json_body)`` for a valid-ish baseline."""
        url = ep.full_url
        query: Dict[str, Any] = {}
        headers: Dict[str, str] = {}

        for param in ep.parameters:
            value = self._sample_value(param)
            if param.location == "path":
                value = self.path_overrides.get(param.name, value)
                url = url.replace("{" + param.name + "}", str(value))
            elif param.location == "query" and (param.required or param.name in self.query_overrides):
                query[param.name] = self.query_overrides.get(param.name, value)
            elif param.location == "header" and param.required:
                headers[param.name] = str(value)

        # Resolve any path placeholders omitted from the parameter array.
        for name in re.findall(r"\{([^{}]+)\}", url):
            value = self.path_overrides.get(name, 1 if "id" in name.lower() else "test")
            url = url.replace("{" + name + "}", str(value))

        body = None
        if ep.method in ("POST", "PUT", "PATCH") and ep.request_body_schema:
            body = self.sample_from_schema(ep.request_body_schema)
        return url, query, headers, body
