#!/usr/bin/env python3
"""APIHound v2.1 CLI."""
from __future__ import annotations

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import click
from core.config import ScanConfig, setup_logging
from core.reporter import Reporter
from core.scanner import Scanner


def _headers_from_cli(values):
    result = {}
    for item in values:
        if ":" not in item:
            raise click.BadParameter(f"Header must be KEY:VALUE, got: {item}")
        key, value = item.split(":", 1)
        key = key.strip()
        if not key:
            raise click.BadParameter("Header name cannot be empty")
        result[key] = value.strip()
    return result


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option("2.1.0", prog_name="APIHound")
@click.option("--spec", default="", help="Path or URL to OpenAPI/Swagger spec")
@click.option("--target", default="", help="Base URL; also overrides servers in the spec")
@click.option("--auth", default="", help="Authorization header value, e.g. 'Bearer TOKEN'")
@click.option("--auth-cookie", default="", help="Cookie header value")
@click.option("--header", "headers", multiple=True, help="Additional request header KEY:VALUE (repeatable)")
@click.option("--checks", default="all", help="Comma-separated check IDs")
@click.option("--crawl", is_flag=True, help="Enable endpoint crawling")
@click.option("--fuzz", is_flag=True, help="Enable crawler parameter/path fuzzing")
@click.option("--waf-bypass", is_flag=True, help="Enable WAF transformation mode")
@click.option("--proxy", default="", help="HTTP/SOCKS proxy, e.g. http://127.0.0.1:8080")
@click.option("--rate-limit", default=10.0, type=click.FloatRange(min=0.1), show_default=True, help="Requests per second")
@click.option("--delay", default=0, type=click.IntRange(min=0), show_default=True, help="Fixed delay between requests in ms")
@click.option("--timeout", default=15, type=click.IntRange(min=1), show_default=True, help="Request timeout in seconds")
@click.option("--retries", default=1, type=click.IntRange(min=0, max=5), show_default=True, help="Retries for network/502-504 failures")
@click.option("--threads", default=5, type=click.IntRange(min=1), show_default=True, help="Reserved worker limit")
@click.option("--max-endpoints", default=0, type=click.IntRange(min=0), show_default=True, help="Cap endpoints tested; 0 = unlimited")
@click.option("--output", default="reports", show_default=True, help="Output directory")
@click.option("--format", "report_format", default="html,json", show_default=True, help="Report formats: html,json,sarif")
@click.option("--lab-mode", is_flag=True, help="Enable broader probes intended for deliberately vulnerable labs")
@click.option("--verbose", is_flag=True, help="Verbose logging")
@click.option("--user-id", default="", help="Known object/user ID for differential BOLA baseline")
@click.option("--user-id-other", default="", help="Known other-user/object ID for high-confidence BOLA comparison")
@click.option("--no-verify-ssl", is_flag=True, help="Disable TLS certificate verification")
def main(spec, target, auth, auth_cookie, headers, checks, crawl, fuzz, waf_bypass,
         proxy, rate_limit, delay, timeout, retries, threads, max_endpoints, output,
         report_format, lab_mode, verbose, user_id, user_id_other, no_verify_ssl):
    """Authorized API security testing aligned with OWASP API Security Top 10 (2023)."""
    setup_logging(verbose)
    if not spec and not target:
        raise click.UsageError("Provide --spec or --target (or both).")
    formats = [f.strip().lower() for f in report_format.split(",") if f.strip()]
    bad_formats = sorted(set(formats) - {"html", "json", "sarif"})
    if bad_formats:
        raise click.BadParameter(f"Unsupported report format(s): {', '.join(bad_formats)}", param_hint="--format")

    config = ScanConfig(
        target_url=target, spec_path=spec, auth_header=auth, auth_cookie=auth_cookie,
        custom_headers=_headers_from_cli(headers), checks=[c.strip() for c in checks.split(",") if c.strip()],
        crawl=crawl, fuzz=fuzz, lab_mode=lab_mode, proxy=proxy, timeout=timeout,
        rate_limit=rate_limit, delay_ms=delay, threads=threads, retries=retries,
        max_endpoints=max_endpoints, waf_bypass=waf_bypass, user_id=user_id,
        user_id_other=user_id_other, output_dir=output, report_formats=formats,
        verbose=verbose, verify_ssl=not no_verify_ssl,
    )

    click.echo("\n  APIHound v2.1 — OWASP API Security Scanner")
    click.echo(f"  Target:      {target or spec}")
    click.echo(f"  Checks:      {checks}")
    click.echo(f"  Rate limit:  {rate_limit} req/s")
    click.echo(f"  Lab mode:    {'ON' if lab_mode else 'OFF'}")
    click.echo(f"  Reports:     {','.join(formats)}\n")

    scanner = Scanner(config)
    try:
        findings = scanner.run()
        report_files = Reporter(output).generate(findings, scanner.get_scan_metadata(), formats)
        for path in report_files:
            click.echo(f"  Report: {path}")
        critical_or_high = any(f.severity in ("CRITICAL", "HIGH") for f in findings)
        raise SystemExit(1 if critical_or_high else 0)
    except KeyboardInterrupt:
        click.echo("\n[!] Scan interrupted by user.")
        raise SystemExit(130)
    finally:
        scanner.close()


if __name__ == "__main__":
    main()
