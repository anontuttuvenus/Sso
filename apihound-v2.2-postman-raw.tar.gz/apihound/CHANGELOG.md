# Changelog

## 2.1.0

- Added local OpenAPI/Swagger `$ref` resolution, path-level parameters, server variables, operation servers, examples/defaults, and Swagger 2 response schemas.
- Added schema-aware request construction so required path/query/header/body values can be materialized from the API specification.
- Reworked BOLA detection around differential responses and explicit `--user-id` / `--user-id-other` evidence; production mode avoids automatic state-changing BOLA probes.
- Added normalized response comparison that ignores common volatile fields such as timestamps and request IDs.
- Added network retries with exponential backoff and richer request statistics.
- Redacts Authorization, Cookie, Set-Cookie, API-key and proxy-auth values from raw report evidence.
- Added finding deduplication.
- Added SARIF 2.1.0 output for CI/security tooling.
- Added repeatable `--header`, `--retries`, `--max-endpoints`, and `--version` CLI options plus stricter option validation.
- Added parser/request-builder/redaction regression tests.

## 2.2.0

- Added `--postman FILE` for standard Postman collections and combined collection + environment JSON.
- Resolves `{{variables}}` locally from collection/environment data without executing Postman scripts.
- Preserves per-request query parameters, non-auth headers, JSON/form/raw bodies as scan baselines.
- Runtime `--auth` overrides any Authorization header stored in imported requests.
- Added `-r FILE` raw HTTP request mode compatible with Burp/sqlmap-style saved requests.
- Raw request parser supports Host, query strings, JSON, form-urlencoded and arbitrary raw bodies.
- Imported request baselines are transparently reused by scanner checks, while mutation payloads still override the relevant fields.
