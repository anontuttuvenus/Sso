"""
APIHound — Global configuration, rate limiting, and logging.
"""
import logging
import time
import threading
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ScanConfig:
    """Central configuration for an APIHound scan."""

    # Target
    target_url: str = ""
    spec_path: str = ""
    postman_path: str = ""
    raw_request_path: str = ""
    auth_header: str = ""
    auth_cookie: str = ""
    custom_headers: dict = field(default_factory=dict)

    # Scan scope
    checks: list = field(default_factory=lambda: ["all"])
    crawl: bool = False
    fuzz: bool = False
    lab_mode: bool = False

    # Network
    proxy: str = ""
    timeout: int = 15
    rate_limit: float = 10.0  # requests per second
    delay_ms: int = 0
    threads: int = 5
    verify_ssl: bool = True
    retries: int = 1
    retry_backoff: float = 0.25
    max_endpoints: int = 0  # 0 = unlimited

    # WAF bypass
    waf_bypass: bool = False

    # Identity for BOLA tests
    user_id: str = ""
    user_id_other: str = ""

    # Output
    output_dir: str = "reports"
    report_formats: list = field(default_factory=lambda: ["html", "json"])
    verbose: bool = False

    def get_headers(self) -> dict:
        """Build default request headers including auth."""
        headers = {
            "User-Agent": "APIHound/2.2 (Security Scanner)",
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
        }
        if self.auth_header:
            headers["Authorization"] = self.auth_header
        if self.auth_cookie:
            headers["Cookie"] = self.auth_cookie
        headers.update(self.custom_headers)
        return headers


class RateLimiter:
    """Token-bucket rate limiter for safe scanning."""

    def __init__(self, rps: float = 10.0, delay_ms: int = 0):
        self._rps = max(rps, 0.1)
        self._delay = delay_ms / 1000.0
        self._interval = 1.0 / self._rps
        self._last = 0.0
        self._lock = threading.Lock()

    def wait(self):
        """Block until allowed to send next request."""
        with self._lock:
            now = time.monotonic()
            elapsed = now - self._last
            wait_time = max(self._interval - elapsed, 0) + self._delay
            if wait_time > 0:
                time.sleep(wait_time)
            self._last = time.monotonic()


@dataclass
class Finding:
    """Single vulnerability finding."""

    check_id: str          # e.g. "API1-BOLA"
    severity: str          # CRITICAL, HIGH, MEDIUM, LOW, INFO
    title: str
    description: str
    endpoint: str
    method: str
    evidence: str = ""     # PoC request/response snippet
    request_raw: str = ""
    response_raw: str = ""
    response_code: int = 0
    confidence: str = "Medium"  # High, Medium, Low
    remediation: str = ""
    references: list = field(default_factory=list)
    cvss: float = 0.0
    tags: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "check_id": self.check_id,
            "severity": self.severity,
            "title": self.title,
            "description": self.description,
            "endpoint": self.endpoint,
            "method": self.method,
            "evidence": self.evidence[:2000],
            "request_raw": self.request_raw[:3000],
            "response_raw": self.response_raw[:3000],
            "response_code": self.response_code,
            "confidence": self.confidence,
            "remediation": self.remediation,
            "references": self.references,
            "cvss": self.cvss,
            "tags": self.tags,
        }


def setup_logging(verbose: bool = False) -> logging.Logger:
    """Configure structured logging."""
    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    logging.basicConfig(level=level, format=fmt, datefmt="%H:%M:%S")
    logger = logging.getLogger("apihound")
    logger.setLevel(level)
    return logger


# Severity ordering for sorting findings
SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
