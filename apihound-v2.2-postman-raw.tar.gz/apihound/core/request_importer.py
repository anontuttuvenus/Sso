"""Import Postman collections/environments and Burp/sqlmap-style raw HTTP requests."""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Tuple
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

from core.openapi_parser import APIEndpoint, APIParameter

logger = logging.getLogger("apihound.importer")
_VAR = re.compile(r"{{\s*([^{}]+?)\s*}}")


def _variables(values: Any) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if isinstance(values, dict):
        # Common wrappers: {key:value}, {values:[...]}, {variable:[...]}
        if "values" in values and isinstance(values["values"], list):
            out.update(_variables(values["values"]))
        if "variable" in values and isinstance(values["variable"], list):
            out.update(_variables(values["variable"]))
        for k, v in values.items():
            if k in {"values", "variable"}:
                continue
            if isinstance(v, (str, int, float, bool)) or v is None:
                out[str(k)] = "" if v is None else str(v)
        return out
    if isinstance(values, list):
        for item in values:
            if not isinstance(item, dict) or item.get("disabled"):
                continue
            key = item.get("key", item.get("name"))
            if key is None:
                continue
            val = item.get("value", item.get("current", item.get("initial", "")))
            if val is not None:
                out[str(key)] = str(val)
    return out


def resolve_vars(value: Any, variables: Dict[str, str], rounds: int = 8) -> Any:
    """Resolve Postman ``{{name}}`` placeholders recursively without executing scripts."""
    if not isinstance(value, str):
        return value
    result = value
    for _ in range(rounds):
        changed = False
        def repl(match):
            nonlocal changed
            name = match.group(1).strip()
            if name in variables:
                changed = True
                return str(variables[name])
            return match.group(0)
        nxt = _VAR.sub(repl, result)
        result = nxt
        if not changed:
            break
    return result


def _find_collection(root: Any) -> dict | None:
    if isinstance(root, list):
        for value in root:
            found = _find_collection(value)
            if found:
                return found
        return None
    if not isinstance(root, dict):
        return None
    if isinstance(root.get("item"), list) and ("info" in root or "variable" in root):
        return root
    for key in ("collection", "postman_collection", "template", "requests"):
        value = root.get(key)
        if isinstance(value, dict) and isinstance(value.get("item"), list):
            return value
    # Accept a collection-like object even if info was removed during combining.
    if isinstance(root.get("item"), list):
        return root
    for value in root.values():
        if isinstance(value, dict):
            found = _find_collection(value)
            if found:
                return found
    return None


def _collect_environment_vars(root: Any, collection: dict) -> Dict[str, str]:
    vars_: Dict[str, str] = {}
    # Collection variables first; environment/wrapper values override them.
    vars_.update(_variables(collection.get("variable", [])))
    if isinstance(root, list):
        for value in root:
            if isinstance(value, dict) and value is not collection:
                if "values" in value:
                    vars_.update(_variables(value.get("values")))
                if "variable" in value and not isinstance(value.get("item"), list):
                    vars_.update(_variables(value.get("variable")))
        return vars_
    if not isinstance(root, dict):
        return vars_
    for key in ("environment", "env", "postman_environment", "variables", "values"):
        if key in root and root.get(key) is not collection.get("variable"):
            vars_.update(_variables(root.get(key)))
    # Some combined exports keep environment next to collection in a list/object.
    for value in root.values():
        if isinstance(value, dict) and value is not collection:
            if "values" in value and any(k in value for k in ("name", "id", "_postman_variable_scope")):
                vars_.update(_variables(value.get("values")))
    return vars_


def _url_from_postman(raw_url: Any, variables: Dict[str, str]) -> Tuple[str, Dict[str, Any]]:
    query: Dict[str, Any] = {}
    if isinstance(raw_url, str):
        text = resolve_vars(raw_url, variables)
    elif isinstance(raw_url, dict):
        text = resolve_vars(raw_url.get("raw", ""), variables)
        if not text:
            protocol = resolve_vars(str(raw_url.get("protocol", "https")), variables)
            host = raw_url.get("host", [])
            host = ".".join(str(resolve_vars(x, variables)) for x in host) if isinstance(host, list) else resolve_vars(str(host), variables)
            path = raw_url.get("path", [])
            path = "/".join(str(resolve_vars(x, variables)).strip("/") for x in path) if isinstance(path, list) else resolve_vars(str(path), variables).lstrip("/")
            text = f"{protocol}://{host}/{path}"
        for q in raw_url.get("query", []) or []:
            if isinstance(q, dict) and not q.get("disabled") and q.get("key"):
                query[resolve_vars(str(q["key"]), variables)] = resolve_vars(str(q.get("value", "")), variables)
    else:
        return "", query
    parsed = urlparse(text)
    for k, v in parse_qsl(parsed.query, keep_blank_values=True):
        query.setdefault(k, v)
    clean = urlunparse((parsed.scheme, parsed.netloc, parsed.path or "/", parsed.params, "", ""))
    return clean, query


def _postman_body(body: dict, variables: Dict[str, str]) -> Tuple[Any, Any, str, str]:
    """Return json_body, form_data, raw_body, content_type."""
    if not isinstance(body, dict):
        return None, None, "", "application/json"
    mode = body.get("mode", "")
    if mode == "raw":
        raw = resolve_vars(str(body.get("raw", "")), variables)
        lang = ((body.get("options") or {}).get("raw") or {}).get("language", "")
        ctype = "application/json" if lang == "json" else "text/plain"
        try:
            return json.loads(raw), None, "", "application/json"
        except (json.JSONDecodeError, TypeError):
            return None, None, raw, ctype
    if mode in ("urlencoded", "formdata"):
        pairs = {}
        for row in body.get(mode, []) or []:
            if isinstance(row, dict) and not row.get("disabled") and row.get("key") is not None:
                pairs[resolve_vars(str(row["key"]), variables)] = resolve_vars(str(row.get("value", "")), variables)
        ctype = "application/x-www-form-urlencoded" if mode == "urlencoded" else "multipart/form-data"
        return None, pairs, "", ctype
    if mode == "graphql":
        gql = body.get("graphql", {}) or {}
        payload = {"query": resolve_vars(gql.get("query", ""), variables)}
        variables_text = resolve_vars(gql.get("variables", ""), variables)
        if variables_text:
            try: payload["variables"] = json.loads(variables_text)
            except Exception: payload["variables"] = variables_text
        return payload, None, "", "application/json"
    return None, None, "", "application/json"


class PostmanImporter:
    """Import standard or combined Postman collection + environment JSON.

    No Postman scripts are executed. This is deliberately a data-only parser.
    """
    def parse_file(self, path: str, target_override: str = "") -> List[APIEndpoint]:
        with open(path, encoding="utf-8") as fh:
            return self.parse(fh.read(), target_override)

    def parse(self, text: str, target_override: str = "") -> List[APIEndpoint]:
        root = json.loads(text)
        collection = _find_collection(root)
        if not collection:
            raise ValueError("No Postman collection 'item' tree found in JSON")
        variables = _collect_environment_vars(root, collection)
        endpoints: List[APIEndpoint] = []

        def walk(items: Iterable[Any], inherited_headers: Dict[str, str] | None = None):
            inherited_headers = dict(inherited_headers or {})
            for item in items or []:
                if not isinstance(item, dict):
                    continue
                if isinstance(item.get("item"), list):
                    walk(item["item"], inherited_headers)
                    continue
                req = item.get("request")
                if not isinstance(req, dict):
                    continue
                method = str(req.get("method", "GET")).upper()
                url, query = _url_from_postman(req.get("url", ""), variables)
                if not url:
                    continue
                if target_override:
                    src = urlparse(url); dst = urlparse(target_override)
                    base_path = dst.path.rstrip("/")
                    url = urlunparse((dst.scheme, dst.netloc, base_path + (src.path if src.path.startswith("/") else "/" + src.path), "", "", ""))
                headers = dict(inherited_headers)
                for h in req.get("header", []) or []:
                    if isinstance(h, dict) and not h.get("disabled") and h.get("key"):
                        headers[resolve_vars(str(h["key"]), variables)] = resolve_vars(str(h.get("value", "")), variables)
                # Runtime --auth is authoritative. Do not require secrets to be stored in files.
                headers.pop("Authorization", None); headers.pop("authorization", None)
                json_body, form_data, raw_body, ctype = _postman_body(req.get("body", {}), variables)
                if any(k.lower() == "content-type" for k in headers):
                    ctype = next(v for k, v in headers.items() if k.lower() == "content-type")
                parsed = urlparse(url)
                params = [APIParameter(name=k, location="query", example=v, required=True) for k, v in query.items()]
                ep = APIEndpoint(
                    path=parsed.path or "/", method=method, full_url=url,
                    summary=str(item.get("name", ""))[:200], parameters=params,
                    content_type=ctype,
                )
                ep.imported_headers = headers
                ep.imported_query = query
                ep.imported_json_body = json_body
                ep.imported_form_data = form_data
                ep.imported_raw_body = raw_body
                ep.source_type = "postman"
                endpoints.append(ep)
        walk(collection.get("item", []))
        logger.info("Imported %d requests from Postman collection", len(endpoints))
        return endpoints


class RawRequestImporter:
    """Parse a Burp/sqlmap-style HTTP request file into one APIEndpoint."""
    def parse_file(self, path: str, target_override: str = "") -> List[APIEndpoint]:
        with open(path, "rb") as fh:
            data = fh.read()
        return self.parse(data.decode("utf-8", errors="replace"), target_override)

    def parse(self, text: str, target_override: str = "") -> List[APIEndpoint]:
        normalized = text.replace("\r\n", "\n")
        head, _, body = normalized.partition("\n\n")
        lines = head.split("\n")
        if not lines or not lines[0].strip():
            raise ValueError("Raw request file is empty")
        parts = lines[0].split()
        if len(parts) < 2:
            raise ValueError("First line must look like: GET /path HTTP/1.1")
        method, request_target = parts[0].upper(), parts[1]
        headers: Dict[str, str] = {}
        current = None
        for line in lines[1:]:
            if line[:1] in (" ", "\t") and current:
                headers[current] += " " + line.strip()
                continue
            if ":" not in line:
                continue
            k, v = line.split(":", 1); current = k.strip(); headers[current] = v.strip()
        host = next((v for k, v in headers.items() if k.lower() == "host"), "")
        if request_target.startswith(("http://", "https://")):
            absolute = request_target
        elif target_override:
            absolute = urljoin(target_override.rstrip("/") + "/", request_target.lstrip("/"))
        elif host:
            scheme = "https"
            absolute = f"{scheme}://{host}{request_target if request_target.startswith('/') else '/' + request_target}"
        else:
            raise ValueError("Raw request needs a Host header or --target")
        parsed = urlparse(absolute)
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        url = urlunparse((parsed.scheme, parsed.netloc, parsed.path or "/", parsed.params, "", ""))
        # Host/content-length are generated by httpx. Runtime --auth overrides stored auth.
        cleaned = {k: v for k, v in headers.items() if k.lower() not in {"host", "content-length", "authorization"}}
        content_type = next((v for k, v in headers.items() if k.lower() == "content-type"), "")
        json_body = form_data = None; raw_body = ""
        if body:
            if "application/json" in content_type.lower():
                try: json_body = json.loads(body)
                except json.JSONDecodeError: raw_body = body
            elif "application/x-www-form-urlencoded" in content_type.lower():
                form_data = dict(parse_qsl(body, keep_blank_values=True))
            else:
                raw_body = body
        ep = APIEndpoint(path=parsed.path or "/", method=method, full_url=url, summary=f"Raw request: {method} {parsed.path or '/'}", content_type=content_type or "application/json")
        ep.parameters = [APIParameter(name=k, location="query", example=v, required=True) for k, v in query.items()]
        ep.imported_headers = cleaned; ep.imported_query = query; ep.imported_json_body = json_body
        ep.imported_form_data = form_data; ep.imported_raw_body = raw_body; ep.source_type = "raw"
        return [ep]
