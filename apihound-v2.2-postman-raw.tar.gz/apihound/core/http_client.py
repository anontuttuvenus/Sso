"""HTTP engine with rate limiting, retries, timing, proxying and safe evidence redaction."""
from __future__ import annotations

import logging
import time
from typing import Optional
from urllib.parse import urlsplit, urlunsplit

import httpx

from core.config import RateLimiter, ScanConfig
from core.request_builder import RequestBuilder

logger = logging.getLogger("apihound.http")

_SENSITIVE_HEADERS = {"authorization", "proxy-authorization", "cookie", "set-cookie", "x-api-key", "api-key"}


class HTTPClient:
    def __init__(self, config: ScanConfig, waf_engine=None):
        self.config = config
        self.waf_engine = waf_engine
        self.rate_limiter = RateLimiter(config.rate_limit, config.delay_ms)
        self.request_builder = RequestBuilder()
        self._stats = {"requests": 0, "errors": 0, "waf_blocks": 0, "retries": 0, "bytes_received": 0}
        self._baseline_requests = {}
        kwargs = {"timeout": httpx.Timeout(config.timeout), "verify": config.verify_ssl, "follow_redirects": False}
        if config.proxy:
            kwargs["proxy"] = config.proxy
        self.client = httpx.Client(**kwargs)


    @staticmethod
    def _baseline_key(method: str, url: str):
        try:
            p = urlsplit(url)
            clean = urlunsplit((p.scheme.lower(), p.netloc.lower(), p.path or "/", "", ""))
        except Exception:
            clean = url.split("?", 1)[0]
        return method.upper(), clean.rstrip("/") or "/"

    def register_endpoints(self, endpoints):
        """Register exact imported Postman/raw baselines for transparent request reuse."""
        self._baseline_requests = {}
        for ep in endpoints or []:
            if not getattr(ep, "source_type", "") in {"postman", "raw"}:
                continue
            self._baseline_requests[self._baseline_key(ep.method, ep.full_url)] = ep

    def _apply_imported_baseline(self, method, url, headers, params, json_body, data, raw_body):
        ep = self._baseline_requests.get(self._baseline_key(method, url))
        if ep is None:
            return headers, params, json_body, data, raw_body
        merged_h = dict(getattr(ep, "imported_headers", {}) or {})
        if headers:
            merged_h.update(headers)
        merged_q = dict(getattr(ep, "imported_query", {}) or {})
        if params:
            merged_q.update(params)
        # Explicit mutation arguments always win over imported baseline bodies.
        if json_body is None and data is None and raw_body is None:
            if getattr(ep, "imported_json_body", None) is not None:
                json_body = ep.imported_json_body
            elif getattr(ep, "imported_form_data", None) is not None:
                data = ep.imported_form_data
            elif getattr(ep, "imported_raw_body", ""):
                raw_body = ep.imported_raw_body
        return merged_h, merged_q, json_body, data, raw_body

    def request(self, method: str, url: str, headers: Optional[dict] = None,
                params: Optional[dict] = None, json_body=None, data=None,
                raw_body: Optional[str] = None, follow_redirects: bool = False,
                apply_waf_bypass: bool = False, omit_auth: bool = False) -> Optional[httpx.Response]:
        headers, params, json_body, data, raw_body = self._apply_imported_baseline(
            method, url, headers, params, json_body, data, raw_body)
        merged_headers = self.config.get_headers()
        if headers:
            merged_headers.update(headers)
        # Runtime CLI auth is authoritative over imported/stored request auth.
        if self.config.auth_header and not omit_auth:
            merged_headers["Authorization"] = self.config.auth_header
        if self.config.auth_cookie and not omit_auth:
            merged_headers["Cookie"] = self.config.auth_cookie
        if omit_auth:
            merged_headers.pop("Authorization", None)
            merged_headers.pop("authorization", None)
            merged_headers.pop("Cookie", None)
            merged_headers.pop("cookie", None)
        if apply_waf_bypass and self.waf_engine and self.config.waf_bypass:
            method, url, merged_headers, params, json_body = self.waf_engine.transform_request(
                method, url, merged_headers, params, json_body)

        kwargs = {"method": method.upper(), "url": url, "headers": merged_headers, "follow_redirects": follow_redirects}
        if params:
            kwargs["params"] = params
        if json_body is not None:
            kwargs["json"] = json_body
        elif data is not None:
            kwargs["data"] = data
        elif raw_body is not None:
            kwargs["content"] = raw_body

        attempts = max(1, int(self.config.retries) + 1)
        for attempt in range(attempts):
            self.rate_limiter.wait()
            started = time.perf_counter()
            try:
                resp = self.client.request(**kwargs)
                elapsed = time.perf_counter() - started
                resp.extensions["apihound_elapsed"] = elapsed
                self._stats["requests"] += 1
                self._stats["bytes_received"] += len(resp.content or b"")
                if self._looks_like_waf_block(resp):
                    self._stats["waf_blocks"] += 1
                if resp.status_code in (502, 503, 504) and attempt + 1 < attempts:
                    self._stats["retries"] += 1
                    time.sleep(self.config.retry_backoff * (2 ** attempt))
                    continue
                return resp
            except (httpx.TimeoutException, httpx.RequestError) as exc:
                self._stats["errors"] += 1
                logger.debug("Request error: %s %s -> %s", method, url, exc)
                if attempt + 1 < attempts:
                    self._stats["retries"] += 1
                    time.sleep(self.config.retry_backoff * (2 ** attempt))
                    continue
                return None
        return None

    def request_endpoint(self, ep, *, headers=None, params=None, json_body=None, **kwargs):
        """Send a baseline request using imported or OpenAPI-derived request data."""
        if getattr(ep, "source_type", "") in {"postman", "raw"}:
            return self.request(ep.method, ep.full_url, headers=headers, params=params,
                                json_body=json_body, **kwargs)
        url, built_params, built_headers, built_body = self.request_builder.build(ep)
        if params:
            built_params.update(params)
        if headers:
            built_headers.update(headers)
        if json_body is None:
            json_body = built_body
        return self.request(ep.method, url, headers=built_headers, params=built_params,
                            json_body=json_body, **kwargs)

    @staticmethod
    def _looks_like_waf_block(resp) -> bool:
        if resp.status_code not in (403, 406, 429, 503):
            return False
        body = resp.text[:1000].lower()
        return any(sig in body for sig in ("access denied", "blocked", "web application firewall", "rate limit", "captcha", "challenge"))

    def get(self, url, **kwargs): return self.request("GET", url, **kwargs)
    def post(self, url, **kwargs): return self.request("POST", url, **kwargs)
    def put(self, url, **kwargs): return self.request("PUT", url, **kwargs)
    def delete(self, url, **kwargs): return self.request("DELETE", url, **kwargs)
    def patch(self, url, **kwargs): return self.request("PATCH", url, **kwargs)
    def options(self, url, **kwargs): return self.request("OPTIONS", url, **kwargs)

    @property
    def stats(self): return dict(self._stats)

    def close(self): self.client.close()

    @staticmethod
    def _safe_header_value(name: str, value: str) -> str:
        return "<redacted>" if name.lower() in _SENSITIVE_HEADERS else str(value)

    def build_raw_request(self, method: str, url: str, headers: dict, body: str = "") -> str:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        path = parsed.path or "/"
        if parsed.query:
            path += f"?{parsed.query}"
        lines = [f"{method.upper()} {path} HTTP/1.1", f"Host: {parsed.netloc}"]
        lines.extend(f"{k}: {self._safe_header_value(k, v)}" for k, v in headers.items())
        lines.append("")
        if body:
            lines.append(body)
        return "\r\n".join(lines)

    def build_raw_response(self, resp: httpx.Response, max_body: int = 1500) -> str:
        lines = [f"HTTP/{resp.http_version} {resp.status_code} {resp.reason_phrase or ''}"]
        lines.extend(f"{k}: {self._safe_header_value(k, v)}" for k, v in resp.headers.items())
        lines.append("")
        text = resp.text
        lines.append(text[:max_body] + ("\n... [truncated]" if len(text) > max_body else ""))
        return "\r\n".join(lines)
