import json
import unittest

from core.config import ScanConfig
from core.http_client import HTTPClient
from core.openapi_parser import OpenAPIParser
from core.request_builder import RequestBuilder


class APIHoundV21Tests(unittest.TestCase):
    def test_openapi3_ref_path_params_and_body(self):
        spec = {
            "openapi": "3.0.3",
            "servers": [{"url": "https://{env}.example.test/api", "variables": {"env": {"default": "dev"}}}],
            "paths": {
                "/users/{id}": {
                    "parameters": [{"$ref": "#/components/parameters/UserId"}],
                    "post": {
                        "requestBody": {"content": {"application/json": {"schema": {"$ref": "#/components/schemas/UserUpdate"}}}},
                        "responses": {"200": {"content": {"application/json": {"schema": {"$ref": "#/components/schemas/User"}}}}}
                    }
                }
            },
            "components": {
                "parameters": {"UserId": {"name": "id", "in": "path", "required": True, "schema": {"type": "integer", "example": 42}}},
                "schemas": {
                    "UserUpdate": {"type": "object", "required": ["name"], "properties": {"name": {"type": "string", "example": "Ada"}, "optional": {"type": "string"}}},
                    "User": {"type": "object", "properties": {"id": {"type": "integer"}}}
                }
            }
        }
        eps = OpenAPIParser().parse(json.dumps(spec))
        self.assertEqual(len(eps), 1)
        ep = eps[0]
        self.assertEqual(ep.full_url, "https://dev.example.test/api/users/{id}")
        self.assertEqual(ep.parameters[0].example, 42)
        self.assertEqual(ep.request_body_schema["properties"]["name"]["example"], "Ada")
        self.assertIn("200", ep.response_schemas)
        url, query, headers, body = RequestBuilder().build(ep)
        self.assertEqual(url, "https://dev.example.test/api/users/42")
        self.assertEqual(body, {"name": "Ada"})

    def test_swagger2_path_level_parameter(self):
        spec = {"swagger": "2.0", "host": "api.example.test", "basePath": "/v1", "paths": {
            "/orders/{orderId}": {"parameters": [{"name": "orderId", "in": "path", "required": True, "type": "integer", "default": 7}], "get": {"responses": {"200": {"schema": {"type": "object"}}}}}
        }}
        ep = OpenAPIParser().parse(json.dumps(spec))[0]
        self.assertEqual(RequestBuilder().build(ep)[0], "https://api.example.test/v1/orders/7")
        self.assertIn("200", ep.response_schemas)

    def test_sensitive_headers_redacted(self):
        client = HTTPClient(ScanConfig())
        try:
            raw = client.build_raw_request("GET", "https://example.test/a", {"Authorization": "Bearer secret", "X-API-Key": "abc", "X-Test": "ok"})
            self.assertNotIn("secret", raw)
            self.assertNotIn("abc", raw)
            self.assertIn("X-Test: ok", raw)
        finally:
            client.close()


if __name__ == "__main__":
    unittest.main()

class APIHoundV22ImportTests(unittest.TestCase):
    def test_combined_postman_collection_environment(self):
        from core.request_importer import PostmanImporter
        combined = {
            "collection": {
                "info": {"name": "demo"},
                "variable": [{"key": "version", "value": "v1"}],
                "item": [{
                    "name": "Create user",
                    "request": {
                        "method": "POST",
                        "header": [
                            {"key": "X-Client", "value": "mobile"},
                            {"key": "Authorization", "value": "Bearer STORED_SECRET"}
                        ],
                        "url": {"raw": "{{baseUrl}}/{{version}}/users?expand={{expand}}"},
                        "body": {"mode": "raw", "raw": "{\"email\":\"{{email}}\"}", "options": {"raw": {"language": "json"}}}
                    }
                }]
            },
            "environment": {
                "name": "dev",
                "values": [
                    {"key": "baseUrl", "value": "https://api.example.test"},
                    {"key": "expand", "value": "profile"},
                    {"key": "email", "value": "qa@example.test"}
                ]
            }
        }
        ep = PostmanImporter().parse(json.dumps(combined))[0]
        self.assertEqual(ep.full_url, "https://api.example.test/v1/users")
        self.assertEqual(ep.imported_query, {"expand": "profile"})
        self.assertEqual(ep.imported_headers["X-Client"], "mobile")
        self.assertNotIn("Authorization", ep.imported_headers)
        self.assertEqual(ep.imported_json_body, {"email": "qa@example.test"})

    def test_raw_request_import(self):
        from core.request_importer import RawRequestImporter
        raw = "POST /v1/orders?id=7 HTTP/1.1\r\nHost: api.example.test\r\nAuthorization: Bearer OLD\r\nX-Trace: abc\r\nContent-Type: application/json\r\n\r\n{\"qty\":2}"
        ep = RawRequestImporter().parse(raw)[0]
        self.assertEqual(ep.full_url, "https://api.example.test/v1/orders")
        self.assertEqual(ep.imported_query, {"id": "7"})
        self.assertEqual(ep.imported_json_body, {"qty": 2})
        self.assertEqual(ep.imported_headers["X-Trace"], "abc")
        self.assertNotIn("Authorization", ep.imported_headers)

    def test_imported_baseline_merges_and_runtime_auth_wins(self):
        from core.openapi_parser import APIEndpoint
        cfg = ScanConfig(auth_header="Bearer NEW")
        client = HTTPClient(cfg)
        try:
            ep = APIEndpoint(path="/x", method="POST", full_url="https://api.example.test/x", source_type="postman")
            ep.imported_headers = {"X-Client": "mobile"}
            ep.imported_query = {"lang": "en"}
            ep.imported_json_body = {"name": "base"}
            client.register_endpoints([ep])
            h, q, jb, data, raw = client._apply_imported_baseline("POST", ep.full_url, {"X-Test": "1"}, {"page": "2"}, None, None, None)
            self.assertEqual(h, {"X-Client": "mobile", "X-Test": "1"})
            self.assertEqual(q, {"lang": "en", "page": "2"})
            self.assertEqual(jb, {"name": "base"})
        finally:
            client.close()
