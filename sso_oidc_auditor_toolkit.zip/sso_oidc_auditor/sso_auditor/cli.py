from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Optional

from .auth0 import run_auth0_audit
from .callbacks import run_callback_canary
from .config import AuditorConfig, example_config
from .discovery import run_discovery
from .jwt_utils import lint_jwt, read_token, save_variants, verify_id_token
from .pkce import make_pkce_pair, run_token_negative_tests
from .redirects import run_redirect_tests
from .reporting import Reporter
from .util import pretty

BANNER = "SSO/OIDC/Auth0 Auditor - authorized testing only"


def load_cfg(args) -> Optional[AuditorConfig]:
    if getattr(args, "config", None):
        return AuditorConfig.load(args.config)
    return None


def finish(reporter: Reporter, out: Optional[str]) -> None:
    if out:
        reporter.save(out)
        print(f"Report written to {out}")
    else:
        print(reporter.to_markdown())


def cmd_init_config(args) -> int:
    out = Path(args.out)
    if out.exists() and not args.force:
        print(f"Refusing to overwrite existing file: {out}. Use --force to overwrite.", file=sys.stderr)
        return 2
    out.write_text(json.dumps(example_config(), indent=2), encoding="utf-8")
    print(f"Wrote example config to {out}")
    return 0


def cmd_pkce_generate(args) -> int:
    pair = make_pkce_pair()
    print(json.dumps(pair, indent=2))
    return 0


def cmd_discovery(args) -> int:
    cfg = load_cfg(args)
    assert cfg is not None
    reporter = Reporter("OIDC Discovery Audit")
    reporter.extend(run_discovery(cfg))
    finish(reporter, args.out)
    return 0


def cmd_redirects(args) -> int:
    cfg = load_cfg(args)
    assert cfg is not None
    if args.owned_redirect_uri:
        cfg.owned_test_redirect_uri = args.owned_redirect_uri
    if args.owned_parent_domain:
        cfg.owned_parent_domain = args.owned_parent_domain
    reporter = Reporter("OAuth Redirect URI Audit")
    reporter.extend(run_redirect_tests(cfg, dry_run=args.dry_run))
    finish(reporter, args.out)
    return 0


def cmd_callbacks(args) -> int:
    cfg = load_cfg(args)
    assert cfg is not None
    reporter = Reporter("OAuth Callback Canary Audit")
    reporter.extend(run_callback_canary(cfg, include_xss_probe=args.include_xss_probe))
    finish(reporter, args.out)
    return 0


def cmd_token_test(args) -> int:
    cfg = load_cfg(args)
    assert cfg is not None
    client_secret = None
    if args.client_secret_env:
        client_secret = os.environ.get(args.client_secret_env)
        if not client_secret:
            print(f"Client secret env var {args.client_secret_env} is not set", file=sys.stderr)
            return 2
    reporter = Reporter("PKCE/Token Endpoint Negative Tests")
    reporter.extend(run_token_negative_tests(
        cfg,
        code=args.code,
        code_verifier=args.code_verifier,
        client_secret=client_secret,
        include_correct_exchange=args.include_correct_exchange,
    ))
    finish(reporter, args.out)
    return 0


def cmd_jwt_lint(args) -> int:
    cfg = load_cfg(args)
    token = read_token(args.token, args.token_file)
    reporter = Reporter("JWT/ID Token Audit")
    reporter.extend(lint_jwt(cfg, token))
    if args.verify:
        if cfg is None:
            print("--verify requires --config", file=sys.stderr)
            return 2
        reporter.extend(verify_id_token(cfg, token, expected_nonce=args.expected_nonce))
    finish(reporter, args.out)
    return 0


def cmd_jwt_variants(args) -> int:
    token = read_token(args.token, args.token_file)
    reporter = Reporter("JWT Negative Variant Generator")
    reporter.add(save_variants(token, args.outfile))
    finish(reporter, args.out)
    return 0


def cmd_auth0_audit(args) -> int:
    cfg = load_cfg(args)
    assert cfg is not None
    reporter = Reporter("Auth0 Tenant Read-Only Audit")
    reporter.extend(run_auth0_audit(cfg, token_env=args.token_env))
    finish(reporter, args.out)
    return 0


def cmd_all_safe(args) -> int:
    cfg = load_cfg(args)
    assert cfg is not None
    reporter = Reporter("SSO/OIDC/Auth0 Safe Audit")
    reporter.extend(run_discovery(cfg))
    reporter.extend(run_redirect_tests(cfg, dry_run=args.redirect_dry_run))
    reporter.extend(run_callback_canary(cfg, include_xss_probe=False))
    if args.include_auth0:
        reporter.extend(run_auth0_audit(cfg, token_env=args.token_env))
    finish(reporter, args.out)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=BANNER)
    parser.add_argument("--version", action="version", version="sso-oidc-auditor 1.0")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("init-config", help="Write an example JSON configuration file")
    p.add_argument("--out", default="sso-auditor.config.json")
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_init_config)

    p = sub.add_parser("pkce-generate", help="Generate a PKCE S256 verifier/challenge pair")
    p.set_defaults(func=cmd_pkce_generate)

    def add_common(p):
        p.add_argument("--config", required=True, help="Path to JSON configuration")
        p.add_argument("--out", help="Report output path (.md or .json). If omitted, prints markdown.")

    p = sub.add_parser("discovery", help="Fetch and analyze OIDC discovery metadata")
    add_common(p)
    p.set_defaults(func=cmd_discovery)

    p = sub.add_parser("redirects", help="Generate and optionally request redirect_uri mutation tests")
    add_common(p)
    p.add_argument("--dry-run", action="store_true", help="Only generate authorization URLs; do not send requests")
    p.add_argument("--owned-redirect-uri", help="Owned collector URL for safe redirect tests")
    p.add_argument("--owned-parent-domain", help="Owned parent domain for subdomain mutation tests")
    p.set_defaults(func=cmd_redirects)

    p = sub.add_parser("callback-canary", help="Send harmless canaries to callback/error pages")
    add_common(p)
    p.add_argument("--include-xss-probe", action="store_true", help="Include a harmless reflected-XSS probe string")
    p.set_defaults(func=cmd_callbacks)

    p = sub.add_parser("token-test", help="Run PKCE/token endpoint negative tests using your own test authorization code")
    add_common(p)
    p.add_argument("--code", required=True, help="Authorization code from your own test login")
    p.add_argument("--code-verifier", required=True, help="Correct code_verifier for that test login")
    p.add_argument("--client-secret-env", help="Environment variable containing client_secret for confidential clients")
    p.add_argument("--include-correct-exchange", action="store_true", help="Redeem the code correctly and then test replay. This consumes the code.")
    p.set_defaults(func=cmd_token_test)

    p = sub.add_parser("jwt-lint", help="Decode/lint a JWT or ID Token; optionally verify signature/claims")
    p.add_argument("--config", help="Path to JSON configuration. Required for --verify.")
    p.add_argument("--token", help="Token string")
    p.add_argument("--token-file", help="File containing token")
    p.add_argument("--verify", action="store_true", help="Verify ID Token signature/issuer/audience using configured issuer")
    p.add_argument("--expected-nonce", help="Expected nonce for ID Token validation")
    p.add_argument("--out", help="Report output path (.md or .json)")
    p.set_defaults(func=cmd_jwt_lint)

    p = sub.add_parser("jwt-variants", help="Generate local negative-test JWT variants; does not send them anywhere")
    p.add_argument("--token", help="Token string")
    p.add_argument("--token-file", help="File containing token")
    p.add_argument("--outfile", required=True, help="Output JSON file for variants")
    p.add_argument("--out", help="Report output path (.md or .json)")
    p.set_defaults(func=cmd_jwt_variants)

    p = sub.add_parser("auth0-audit", help="Read-only Auth0 Management API configuration audit")
    add_common(p)
    p.add_argument("--token-env", help="Env var containing read-only Management API token")
    p.set_defaults(func=cmd_auth0_audit)

    p = sub.add_parser("all-safe", help="Run discovery, redirect generation/checks, callback canaries, optionally Auth0 read-only audit")
    add_common(p)
    p.add_argument("--redirect-dry-run", action="store_true", help="Only generate redirect URLs; do not request /authorize")
    p.add_argument("--include-auth0", action="store_true", help="Include read-only Auth0 Management API audit")
    p.add_argument("--token-env", help="Env var containing read-only Management API token")
    p.set_defaults(func=cmd_all_safe)

    return parser


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
