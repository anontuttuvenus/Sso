from __future__ import annotations

from typing import List
from urllib.parse import urlparse

import requests

from .config import AuditorConfig
from .reporting import Finding
from .util import DEFAULT_TIMEOUT, USER_AGENT, add_query_params, hostname, random_state, redact_text


def run_callback_canary(cfg: AuditorConfig, include_xss_probe: bool = False) -> List[Finding]:
    findings: List[Finding] = []
    canary = random_state("sso_callback_canary")
    owned = cfg.owned_test_redirect_uri or "https://collector.security-test.example.com/cb"
    xss_probe = "\"><img src=x onerror=console.log('sso_callback_canary')>"

    for callback in cfg.callback_urls:
        params = {
            "error": "access_denied",
            "error_description": canary,
            "state": canary,
            "returnTo": owned,
            "next": owned,
        }
        if include_xss_probe:
            params["xss_probe"] = xss_probe
        url = add_query_params(callback, params)
        try:
            r = requests.get(
                url,
                allow_redirects=False,
                timeout=DEFAULT_TIMEOUT,
                headers={"User-Agent": USER_AGENT},
            )
            body = r.text or ""
            loc = r.headers.get("Location", "")
            reflected = canary in body
            reflected_xss = include_xss_probe and xss_probe in body
            external_redirect = False
            loc_host = hostname(loc)
            allowed_hosts = set(cfg.allowed_hosts)
            if loc_host and loc_host not in allowed_hosts:
                external_redirect = True

            if reflected_xss:
                findings.append(Finding(
                    title="Callback page reflects raw XSS probe",
                    severity="high",
                    status="potential",
                    description="A harmless XSS probe was reflected verbatim in a callback/error page. Manual confirmation is required to determine exploitability and context.",
                    evidence={"url": url, "status_code": r.status_code, "body_snippet": redact_text(body, 800)},
                    recommendation="HTML-encode all OAuth callback/error parameters and avoid rendering raw state/error_description.",
                ))
            elif reflected:
                findings.append(Finding(
                    title="Callback page reflects OAuth canary parameter",
                    severity="low",
                    status="potential",
                    description="The callback/error page reflects controlled OAuth parameters. This is not necessarily exploitable, but it is worth reviewing for HTML encoding and DOM sinks.",
                    evidence={"url": url, "status_code": r.status_code, "body_snippet": redact_text(body, 800)},
                    recommendation="Ensure reflected values are contextually encoded and covered by CSP.",
                ))
            else:
                findings.append(Finding(
                    title="Callback canary not reflected",
                    severity="info",
                    status="passed",
                    evidence={"url": url, "status_code": r.status_code, "location": redact_text(loc, 500)},
                ))

            if external_redirect:
                findings.append(Finding(
                    title="Callback produced redirect to external host",
                    severity="medium",
                    status="potential",
                    description="A callback/error request caused a redirect to a host outside the configured allowed hosts. If attacker-controlled, this can be chained with OAuth state/code leakage.",
                    evidence={"url": url, "status_code": r.status_code, "location": redact_text(loc, 700)},
                    recommendation="Restrict returnTo/next/redirect/appState to relative paths or a strict allowlist.",
                ))
        except Exception as exc:
            findings.append(Finding(
                title="Callback canary request failed",
                severity="info",
                status="error",
                evidence={"callback": callback, "error": redact_text(str(exc), 500)},
            ))
    return findings
