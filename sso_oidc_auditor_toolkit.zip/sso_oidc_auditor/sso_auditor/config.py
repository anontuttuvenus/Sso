from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .util import env_expand, normalize_issuer


@dataclass
class Auth0ManagementConfig:
    domain: Optional[str] = None
    token_env: str = "AUTH0_MGMT_TOKEN"


@dataclass
class AuditorConfig:
    issuer: str
    client_id: str
    redirect_uri: str
    scope: str = "openid profile email"
    audience: Optional[str] = None
    authorization_endpoint: Optional[str] = None
    token_endpoint: Optional[str] = None
    jwks_uri: Optional[str] = None
    callback_urls: List[str] = field(default_factory=list)
    allowed_hosts: List[str] = field(default_factory=list)
    owned_test_redirect_uri: Optional[str] = None
    owned_parent_domain: Optional[str] = None
    auth0_management: Auth0ManagementConfig = field(default_factory=Auth0ManagementConfig)

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "AuditorConfig":
        d = env_expand(d)
        mgmt = d.get("auth0_management") or {}
        cfg = AuditorConfig(
            issuer=normalize_issuer(d["issuer"]),
            client_id=d["client_id"],
            redirect_uri=d["redirect_uri"],
            scope=d.get("scope", "openid profile email"),
            audience=d.get("audience"),
            authorization_endpoint=d.get("authorization_endpoint"),
            token_endpoint=d.get("token_endpoint"),
            jwks_uri=d.get("jwks_uri"),
            callback_urls=d.get("callback_urls") or [d["redirect_uri"]],
            allowed_hosts=d.get("allowed_hosts") or [],
            owned_test_redirect_uri=d.get("owned_test_redirect_uri"),
            owned_parent_domain=d.get("owned_parent_domain"),
            auth0_management=Auth0ManagementConfig(
                domain=mgmt.get("domain"),
                token_env=mgmt.get("token_env", "AUTH0_MGMT_TOKEN"),
            ),
        )
        if not cfg.allowed_hosts:
            from urllib.parse import urlparse
            hosts = set()
            for u in [cfg.redirect_uri, *cfg.callback_urls]:
                host = (urlparse(u).hostname or "").lower()
                if host:
                    hosts.add(host)
            cfg.allowed_hosts = sorted(hosts)
        return cfg

    @staticmethod
    def load(path: str) -> "AuditorConfig":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return AuditorConfig.from_dict(data)

    def effective_authorization_endpoint(self) -> str:
        return self.authorization_endpoint or f"{self.issuer}authorize"

    def effective_token_endpoint(self) -> str:
        return self.token_endpoint or f"{self.issuer}oauth/token"

    def effective_jwks_uri(self) -> str:
        return self.jwks_uri or f"{self.issuer}.well-known/jwks.json"


def example_config() -> Dict[str, Any]:
    return {
        "issuer": "https://YOUR_TENANT.auth0.com/",
        "client_id": "YOUR_TEST_CLIENT_ID",
        "redirect_uri": "https://app.example.com/callback",
        "scope": "openid profile email",
        "audience": "https://api.example.com/",
        "callback_urls": [
            "https://app.example.com/callback",
            "https://app.example.com/oauth/callback"
        ],
        "allowed_hosts": [
            "app.example.com"
        ],
        "owned_test_redirect_uri": "https://collector.security-test.example.com/cb",
        "owned_parent_domain": "security-test.example.com",
        "auth0_management": {
            "domain": "https://YOUR_TENANT.auth0.com",
            "token_env": "AUTH0_MGMT_TOKEN"
        }
    }
