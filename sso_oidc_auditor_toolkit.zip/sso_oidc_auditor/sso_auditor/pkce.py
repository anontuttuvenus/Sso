from __future__ import annotations

import base64
import hashlib
import os
from typing import Dict, List, Optional

import requests

from .config import AuditorConfig
from .reporting import Finding
from .util import DEFAULT_TIMEOUT, USER_AGENT, redact_text, redact_value


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def make_pkce_pair() -> Dict[str, str]:
    verifier = b64url(os.urandom(32))
    challenge = b64url(hashlib.sha256(verifier.encode("ascii")).digest())
    return {"code_verifier": verifier, "code_challenge": challenge, "code_challenge_method": "S256"}


def token_exchange(cfg: AuditorConfig, code: str, verifier: Optional[str], redirect_uri: Optional[str] = None, client_secret: Optional[str] = None) -> requests.Response:
    data = {
        "grant_type": "authorization_code",
        "client_id": cfg.client_id,
        "code": code,
        "redirect_uri": redirect_uri or cfg.redirect_uri,
    }
    if verifier is not None:
        data["code_verifier"] = verifier
    if client_secret:
        data["client_secret"] = client_secret
    return requests.post(
        cfg.effective_token_endpoint(),
        data=data,
        timeout=DEFAULT_TIMEOUT,
        headers={"User-Agent": USER_AGENT},
    )


def classify_exchange(name: str, response: requests.Response, expected_reject: bool) -> Finding:
    status = response.status_code
    text = response.text or ""
    try:
        parsed = response.json()
    except Exception:
        parsed = None
    success = 200 <= status < 300

    if expected_reject and success:
        return Finding(
            title=f"PKCE/token negative test unexpectedly succeeded: {name}",
            severity="high",
            status="potential",
            description="A token endpoint negative test succeeded when it should usually be rejected. Confirm with a fresh code and test account, because token endpoint behavior can vary after previous failed attempts.",
            evidence={"test": name, "status_code": status, "body": redact_value(parsed) if parsed is not None else redact_text(text, 800)},
            recommendation="Require PKCE S256 for public clients and bind code to client_id, redirect_uri, and code_verifier.",
        )

    if not expected_reject and not success:
        return Finding(
            title=f"Correct token exchange failed: {name}",
            severity="info",
            status="observed",
            description="The expected-valid token exchange failed. The code may have expired, been invalidated by prior negative tests, or the supplied verifier/client credentials may be wrong.",
            evidence={"test": name, "status_code": status, "body": redact_value(parsed) if parsed is not None else redact_text(text, 800)},
        )

    if expected_reject:
        return Finding(
            title=f"PKCE/token negative test rejected: {name}",
            severity="info",
            status="passed",
            evidence={"test": name, "status_code": status, "body": redact_value(parsed) if parsed is not None else redact_text(text, 800)},
        )

    return Finding(
        title=f"Correct token exchange succeeded: {name}",
        severity="info",
        status="observed",
        description="A correct token exchange succeeded. Response details are redacted by default.",
        evidence={"test": name, "status_code": status, "body": redact_value(parsed) if parsed is not None else redact_text(text, 800)},
    )


def run_token_negative_tests(cfg: AuditorConfig, code: str, code_verifier: str, client_secret: Optional[str] = None, include_correct_exchange: bool = False) -> List[Finding]:
    findings: List[Finding] = []
    tests = [
        ("missing code_verifier", None, cfg.redirect_uri, True),
        ("wrong code_verifier", "wrong-verifier-for-authorized-test", cfg.redirect_uri, True),
        ("wrong redirect_uri", code_verifier, cfg.redirect_uri.rstrip("/") + "/wrong-callback", True),
    ]
    if include_correct_exchange:
        tests.append(("correct exchange", code_verifier, cfg.redirect_uri, False))
        tests.append(("replay same code after correct exchange", code_verifier, cfg.redirect_uri, True))

    for name, verifier, redirect_uri, expected_reject in tests:
        try:
            r = token_exchange(cfg, code, verifier, redirect_uri, client_secret=client_secret)
            findings.append(classify_exchange(name, r, expected_reject))
        except Exception as exc:
            findings.append(Finding(
                title=f"Token exchange test failed: {name}",
                severity="info",
                status="error",
                evidence={"test": name, "error": redact_text(str(exc), 500)},
            ))
    return findings
