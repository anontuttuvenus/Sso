from __future__ import annotations

import hashlib
from typing import Dict, List, Optional
from urllib.parse import urlencode, urlparse

import requests

from .config import AuditorConfig
from .reporting import Finding
from .util import DEFAULT_TIMEOUT, USER_AGENT, hostname, random_state, redact_text


def pkce_challenge_for_placeholder() -> str:
    digest = hashlib.sha256(b"sso-auditor-placeholder-verifier").digest()
    import base64
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def build_authorize_url(cfg: AuditorConfig, redirect_uri: str, extra_params: Optional[Dict[str, str]] = None) -> str:
    params = {
        "client_id": cfg.client_id,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "scope": cfg.scope,
        "state": random_state(),
        "code_challenge": pkce_challenge_for_placeholder(),
        "code_challenge_method": "S256",
    }
    if cfg.audience:
        params["audience"] = cfg.audience
    if extra_params:
        params.update(extra_params)
    return f"{cfg.effective_authorization_endpoint()}?{urlencode(params)}"


def generate_redirect_mutations(cfg: AuditorConfig) -> List[str]:
    base = cfg.redirect_uri
    parsed = urlparse(base)
    base_host = parsed.hostname or "app.example.com"
    base_path = parsed.path or "/callback"
    owned = cfg.owned_test_redirect_uri
    owned_host = hostname(owned) if owned else None
    parent = cfg.owned_parent_domain

    mutations = [base]

    if owned:
        mutations.extend([
            f"{base}?next={owned}",
            f"{base}?returnTo={owned}",
            f"{base}?redirect={owned}",
            f"{base}?continue={owned}",
            f"{parsed.scheme}://{base_host}{base_path}/../redirect?to={owned}",
            f"{parsed.scheme}://{owned_host}/@{base_host}{base_path}",
            f"{parsed.scheme}://{base_host}%5c@{owned_host}{base_path}",
            f"{parsed.scheme}://{base_host}%2e{owned_host}{base_path}",
        ])
    if parent:
        mutations.extend([
            f"{parsed.scheme}://{base_host}.{parent}{base_path}",
            f"{parsed.scheme}://{base_host}@{parent}{base_path}",
        ])
    mutations.extend([
        f"{parsed.scheme}://{base_host}.{base_path}",
        f"{parsed.scheme}://{base_host}:443{base_path}",
        f"{parsed.scheme}://{base_host}%2f.example{base_path}",
    ])

    # Preserve order, remove duplicates.
    seen = set()
    out = []
    for u in mutations:
        if u not in seen:
            out.append(u)
            seen.add(u)
    return out


def classify_authorize_response(cfg: AuditorConfig, redirect_uri: str, status: int, location: str, body: str) -> Finding:
    lower_body = body.lower()
    loc_host = hostname(location)
    owned_host = hostname(cfg.owned_test_redirect_uri) if cfg.owned_test_redirect_uri else ""
    base_host = hostname(cfg.redirect_uri)
    issuer_host = hostname(cfg.issuer)

    evidence = {
        "tested_redirect_uri": redirect_uri,
        "status_code": status,
        "location": redact_text(location, 700),
        "body_snippet": redact_text(body, 500),
    }

    if location and owned_host and (loc_host == owned_host or loc_host.endswith("." + owned_host)):
        return Finding(
            title="Authorization endpoint redirected toward owned test host",
            severity="high",
            status="potential",
            description="The authorization endpoint produced a redirect to an owned test host for a mutated redirect_uri. Confirm manually with a test account and verify whether a code or token can be delivered.",
            evidence=evidence,
            recommendation="Use exact redirect URI allowlisting and remove callback open-redirect chains.",
        )

    if status in {400, 401, 403} or "invalid_redirect" in lower_body or "unauthorized" in lower_body:
        return Finding(
            title="Redirect URI mutation rejected",
            severity="info",
            status="passed",
            description="The authorization endpoint appears to reject this redirect URI mutation.",
            evidence=evidence,
        )

    if location and loc_host and loc_host not in {base_host, issuer_host}:
        return Finding(
            title="Authorization endpoint redirected to unexpected host",
            severity="medium",
            status="potential",
            description="The authorization endpoint returned a redirect to a host that was not the configured app host or issuer host. This may be a normal login-page redirect or a validation weakness depending on tenant behavior.",
            evidence=evidence,
            recommendation="Manually verify host purpose. Reject redirects to unregistered hosts.",
        )

    return Finding(
        title="Redirect URI mutation produced non-final response",
        severity="info",
        status="observed",
        description="The response did not clearly accept or reject the mutation. Many IdPs require user interaction before redirect_uri impact is visible. Use the generated authorization URL with a controlled test account if program rules allow.",
        evidence=evidence,
    )


def run_redirect_tests(cfg: AuditorConfig, dry_run: bool = False) -> List[Finding]:
    findings: List[Finding] = []
    mutations = generate_redirect_mutations(cfg)

    findings.append(Finding(
        title="Generated redirect URI test cases",
        severity="info",
        status="observed",
        description="Use these authorization URLs with only controlled test accounts. The tool does not follow login redirects or collect real-user tokens.",
        evidence={"authorization_urls": [build_authorize_url(cfg, m) for m in mutations]},
    ))

    if dry_run:
        return findings

    for m in mutations:
        try:
            r = requests.get(
                build_authorize_url(cfg, m),
                allow_redirects=False,
                timeout=DEFAULT_TIMEOUT,
                headers={"User-Agent": USER_AGENT},
            )
            findings.append(classify_authorize_response(cfg, m, r.status_code, r.headers.get("Location", ""), r.text[:1200]))
        except Exception as exc:
            findings.append(Finding(
                title="Redirect URI mutation request failed",
                severity="info",
                status="error",
                evidence={"tested_redirect_uri": m, "error": redact_text(str(exc), 500)},
            ))
    return findings
