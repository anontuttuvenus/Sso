from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .util import pretty, redact_value, utc_now

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


@dataclass
class Finding:
    title: str
    severity: str = "info"
    status: str = "observed"  # observed, potential, passed, error, skipped
    description: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)
    recommendation: str = ""

    def redacted(self) -> Dict[str, Any]:
        d = asdict(self)
        d["evidence"] = redact_value(d.get("evidence", {}))
        return d


class Reporter:
    def __init__(self, name: str = "SSO/OIDC Auditor") -> None:
        self.name = name
        self.started_at = utc_now()
        self.findings: List[Finding] = []

    def add(self, finding: Finding) -> None:
        sev = finding.severity.lower()
        if sev not in SEVERITY_ORDER:
            finding.severity = "info"
        self.findings.append(finding)

    def extend(self, findings: List[Finding]) -> None:
        for f in findings:
            self.add(f)

    def sorted_findings(self) -> List[Finding]:
        return sorted(self.findings, key=lambda f: (SEVERITY_ORDER.get(f.severity.lower(), 99), f.title))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "started_at": self.started_at,
            "generated_at": utc_now(),
            "finding_count": len(self.findings),
            "findings": [f.redacted() for f in self.sorted_findings()],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True)

    def to_markdown(self) -> str:
        lines = [f"# {self.name} Report", "", f"Generated: {utc_now()}", "", f"Findings: {len(self.findings)}", ""]
        if not self.findings:
            lines.append("No findings recorded.")
            return "\n".join(lines)

        lines.append("| Severity | Status | Finding |")
        lines.append("|---|---|---|")
        for f in self.sorted_findings():
            lines.append(f"| {f.severity.upper()} | {f.status} | {f.title} |")
        lines.append("")

        for idx, f in enumerate(self.sorted_findings(), 1):
            lines.append(f"## {idx}. {f.title}")
            lines.append("")
            lines.append(f"**Severity:** {f.severity.upper()}  ")
            lines.append(f"**Status:** {f.status}")
            lines.append("")
            if f.description:
                lines.append(f.description)
                lines.append("")
            if f.evidence:
                lines.append("**Evidence**")
                lines.append("")
                lines.append("```json")
                lines.append(pretty(f.evidence))
                lines.append("```")
                lines.append("")
            if f.recommendation:
                lines.append("**Recommendation**")
                lines.append("")
                lines.append(f.recommendation)
                lines.append("")
        return "\n".join(lines)

    def save(self, out: Optional[str]) -> None:
        if not out:
            return
        p = Path(out)
        p.parent.mkdir(parents=True, exist_ok=True)
        if p.suffix.lower() == ".json":
            p.write_text(self.to_json(), encoding="utf-8")
        else:
            p.write_text(self.to_markdown(), encoding="utf-8")
