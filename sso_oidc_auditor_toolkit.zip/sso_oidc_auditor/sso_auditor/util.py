from __future__ import annotations

import base64
import json
import os
import re
import secrets
import textwrap
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Optional
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

DEFAULT_TIMEOUT = 15
USER_AGENT = "sso-oidc-auditor/1.0 authorized-security-testing"


SENSITIVE_KEYS = {
    "access_token",
    "id_token",
    "refresh_token",
    "token",
    "client_secret",
    "authorization",
    "code",
    "code_verifier",
}

TOKEN_RE = re.compile(r"(?i)(access_token|id_token|refresh_token|client_secret|code|code_verifier|token)=([^&\s]+)")
BEARER_RE = re.compile(r"(?i)bearer\s+([A-Za-z0-9._~+\-/=]+)")
JWT_RE = re.compile(r"eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]*")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_issuer(value: str) -> str:
    if not value:
        return value
    value = value.strip()
    if not value.endswith("/"):
        value += "/"
    return value


def b64url_decode(part: str) -> bytes:
    padding = "=" * (-len(part) % 4)
    return base64.urlsafe_b64decode(part + padding)


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def random_state(prefix: str = "sso_auditor") -> str:
    return f"{prefix}_{secrets.token_urlsafe(24)}"


def safe_json_loads(text: str) -> Any:
    try:
        return json.loads(text)
    except Exception:
        return None


def redact_value(value: Any) -> Any:
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            if k.lower() in SENSITIVE_KEYS:
                out[k] = "<redacted>"
            else:
                out[k] = redact_value(v)
        return out
    if isinstance(value, list):
        return [redact_value(v) for v in value]
    if isinstance(value, str):
        return redact_text(value)
    return value


def redact_text(text: str, max_len: Optional[int] = None) -> str:
    if text is None:
        return ""
    text = str(text)
    text = BEARER_RE.sub("Bearer <redacted>", text)
    text = TOKEN_RE.sub(lambda m: f"{m.group(1)}=<redacted>", text)
    text = JWT_RE.sub("<jwt-redacted>", text)
    if max_len and len(text) > max_len:
        return text[:max_len] + "...<truncated>"
    return text


def env_expand(value: Any) -> Any:
    if isinstance(value, str):
        return os.path.expandvars(value)
    if isinstance(value, list):
        return [env_expand(v) for v in value]
    if isinstance(value, dict):
        return {k: env_expand(v) for k, v in value.items()}
    return value


def add_query_params(url: str, params: Dict[str, str]) -> str:
    parsed = urlparse(url)
    q = dict(parse_qsl(parsed.query, keep_blank_values=True))
    q.update(params)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, urlencode(q), parsed.fragment))


def same_host(url_a: str, url_b: str) -> bool:
    try:
        return urlparse(url_a).netloc.lower() == urlparse(url_b).netloc.lower()
    except Exception:
        return False


def hostname(url: str) -> str:
    return (urlparse(url).hostname or "").lower()


def is_https_url(url: str) -> bool:
    return urlparse(url).scheme.lower() == "https"


def looks_external(url: str, allowed_hosts: Iterable[str]) -> bool:
    host = hostname(url)
    if not host:
        return False
    allowed = {h.lower() for h in allowed_hosts if h}
    return host not in allowed


def pretty(obj: Any) -> str:
    return json.dumps(redact_value(obj), indent=2, sort_keys=True)


def wrap(text: str, width: int = 100) -> str:
    return "\n".join(textwrap.wrap(text, width=width))
