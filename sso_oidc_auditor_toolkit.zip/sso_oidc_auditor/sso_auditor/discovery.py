from __future__ import annotations

from typing import Any, Dict, List

import requests

from .config import AuditorConfig
from .reporting import Finding
from .util import DEFAULT_TIMEOUT, USER_AGENT, is_https_url, normalize_issuer, redact_text


def fetch_discovery(cfg: AuditorConfig) -> Dict[str, Any]:
    url = f"{cfg.issuer}.well-known/openid-configuration"
    r = requests.get(url, timeout=DEFAULT_TIMEOUT, headers={"User-Agent": USER_AGENT})
    r.raise_for_status()
    return r.json()


def analyze_discovery(cfg: AuditorConfig, meta: Dict[str, Any]) -> List[Finding]:
    findings: List[Finding] = []

    issuer = normalize_issuer(meta.get("issuer", ""))
    if issuer and issuer != cfg.issuer:
        findings.append(Finding(
            title="Discovery issuer differs from configured issuer",
            severity="medium",
            status="potential",
            description="The issuer in discovery metadata does not match the configured issuer. This can cause mix-up or token validation errors if applications use inconsistent issuer values.",
            evidence={"configured_issuer": cfg.issuer, "discovered_issuer": issuer},
            recommendation="Pin the exact issuer used by your tenant/custom domain and validate tokens against that exact value.",
        ))

    if not is_https_url(meta.get("authorization_endpoint", "")):
        findings.append(Finding(
            title="Authorization endpoint is not HTTPS",
            severity="high",
            status="observed",
            evidence={"authorization_endpoint": meta.get("authorization_endpoint")},
            recommendation="Use HTTPS for all OAuth/OIDC endpoints.",
        ))

    response_types = meta.get("response_types_supported") or []
    risky_response_types = [rt for rt in response_types if "token" in rt or rt == "id_token" or "id_token" in rt and "code" in rt]
    if risky_response_types:
        findings.append(Finding(
            title="Discovery metadata advertises implicit or hybrid response types",
            severity="medium",
            status="potential",
            description="Implicit/hybrid flows expose tokens in browser-facing channels and should generally be disabled unless there is a documented exception.",
            evidence={"response_types_supported": risky_response_types},
            recommendation="Prefer Authorization Code + PKCE. Disable legacy implicit/hybrid grants where possible.",
        ))

    grants = meta.get("grant_types_supported") or []
    risky_grants = [g for g in grants if g in {"password", "urn:ietf:params:oauth:grant-type:jwt-bearer"}]
    if risky_grants:
        findings.append(Finding(
            title="Discovery metadata advertises sensitive grant types",
            severity="medium",
            status="potential",
            description="Password/ROPC and assertion grants increase risk when enabled broadly. They should be restricted to explicit legacy or machine-to-machine use cases.",
            evidence={"grant_types_supported": risky_grants},
            recommendation="Disable unused grants and document any exceptions.",
        ))

    algs = meta.get("id_token_signing_alg_values_supported") or []
    risky_algs = [a for a in algs if a.lower() == "none" or a.upper().startswith("HS")]
    if risky_algs:
        findings.append(Finding(
            title="Potentially risky ID Token signing algorithms advertised",
            severity="medium",
            status="potential",
            description="Clients should never accept alg=none and should explicitly allowlist expected algorithms. HS algorithms can be safe in narrow deployments but often trigger HS/RS confusion mistakes.",
            evidence={"id_token_signing_alg_values_supported": risky_algs},
            recommendation="Configure clients to allowlist the expected asymmetric algorithm such as RS256 or ES256 and reject alg=none.",
        ))

    jwks_uri = meta.get("jwks_uri")
    if jwks_uri and not is_https_url(jwks_uri):
        findings.append(Finding(
            title="JWKS URI is not HTTPS",
            severity="high",
            status="observed",
            evidence={"jwks_uri": jwks_uri},
            recommendation="Serve JWKS only over HTTPS and pin issuer metadata.",
        ))

    token_endpoint = meta.get("token_endpoint")
    if token_endpoint and not is_https_url(token_endpoint):
        findings.append(Finding(
            title="Token endpoint is not HTTPS",
            severity="critical",
            status="observed",
            evidence={"token_endpoint": token_endpoint},
            recommendation="Use HTTPS for token exchange.",
        ))

    findings.append(Finding(
        title="Discovery metadata fetched",
        severity="info",
        status="observed",
        description="OIDC discovery metadata was fetched and summarized. Review supported flows, algorithms, and endpoints for tenant drift.",
        evidence={
            "issuer": meta.get("issuer"),
            "authorization_endpoint": meta.get("authorization_endpoint"),
            "token_endpoint": meta.get("token_endpoint"),
            "jwks_uri": meta.get("jwks_uri"),
            "response_types_supported": response_types,
            "grant_types_supported": grants,
            "id_token_signing_alg_values_supported": algs,
        },
    ))

    return findings


def run_discovery(cfg: AuditorConfig) -> List[Finding]:
    try:
        meta = fetch_discovery(cfg)
        return analyze_discovery(cfg, meta)
    except Exception as exc:
        return [Finding(
            title="Discovery metadata fetch failed",
            severity="info",
            status="error",
            description="The tool could not fetch or parse OIDC discovery metadata.",
            evidence={"issuer": cfg.issuer, "error": redact_text(str(exc), 500)},
            recommendation="Confirm the issuer URL and network access, then retry.",
        )]
