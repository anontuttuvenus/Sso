from __future__ import annotations

import os
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import urlparse

import requests

from .config import AuditorConfig
from .reporting import Finding
from .util import DEFAULT_TIMEOUT, USER_AGENT, hostname, is_https_url, redact_text


RISKY_GRANTS = {"password", "http://auth0.com/oauth/grant-type/password-realm", "implicit"}
WRITE_SCOPE_PREFIXES = ("create:", "update:", "delete:")


def management_base(cfg: AuditorConfig) -> str:
    domain = cfg.auth0_management.domain or cfg.issuer
    return domain.rstrip("/") + "/api/v2"


def auth_headers(token: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT}


def paged_get(base: str, token: str, path: str, params: Optional[Dict[str, Any]] = None, limit_pages: int = 5) -> List[Dict[str, Any]]:
    params = dict(params or {})
    params.setdefault("per_page", 100)
    params.setdefault("include_totals", "true")
    out: List[Dict[str, Any]] = []
    for page in range(limit_pages):
        params["page"] = page
        r = requests.get(base + path, params=params, headers=auth_headers(token), timeout=DEFAULT_TIMEOUT)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and "clients" in data:
            items = data["clients"]
        elif isinstance(data, dict) and "connections" in data:
            items = data["connections"]
        elif isinstance(data, dict) and "resource_servers" in data:
            items = data["resource_servers"]
        elif isinstance(data, dict) and "grants" in data:
            items = data["grants"]
        elif isinstance(data, list):
            items = data
        elif isinstance(data, dict) and "items" in data:
            items = data["items"]
        else:
            items = []
        out.extend(items)
        if not isinstance(data, dict) or data.get("length", len(items)) < params["per_page"]:
            break
    return out


def risky_url_flags(url: str) -> List[str]:
    flags: List[str] = []
    u = url.strip()
    if "*" in u:
        flags.append("wildcard")
    if "localhost" in u.lower() or "127.0.0.1" in u or "0.0.0.0" in u:
        flags.append("localhost")
    if not is_https_url(u):
        flags.append("non_https")
    if "{" in u or "}" in u or "<" in u or ">" in u:
        flags.append("placeholder_or_template")
    return flags


def audit_clients(base: str, token: str) -> List[Finding]:
    findings: List[Finding] = []
    fields = "name,client_id,app_type,callbacks,allowed_logout_urls,web_origins,allowed_origins,grant_types,oidc_conformant"
    try:
        clients = paged_get(base, token, "/clients", {"fields": fields, "include_fields": "true"})
    except Exception as exc:
        return [Finding(
            title="Auth0 clients fetch failed",
            severity="info",
            status="error",
            evidence={"error": redact_text(str(exc), 700)},
        )]

    for c in clients:
        name = c.get("name") or c.get("client_id")
        for field in ["callbacks", "allowed_logout_urls", "web_origins", "allowed_origins"]:
            for url in c.get(field) or []:
                flags = risky_url_flags(url)
                if flags:
                    findings.append(Finding(
                        title=f"Auth0 client has risky URL setting: {field}",
                        severity="medium" if "wildcard" in flags or "non_https" in flags else "low",
                        status="potential",
                        description="Auth0 application URL settings should be exact HTTPS allowlists in production. Wildcards, localhost, placeholders, and non-HTTPS URLs can enable token/code leakage or tenant drift.",
                        evidence={"client_name": name, "client_id": c.get("client_id"), "field": field, "url": url, "flags": flags},
                        recommendation="Remove production wildcards/placeholders/localhost and restrict callbacks/logout/origins to exact HTTPS URLs.",
                    ))
        grants = set(c.get("grant_types") or [])
        risky_grants = sorted(grants.intersection(RISKY_GRANTS))
        if risky_grants:
            findings.append(Finding(
                title="Auth0 client has risky grant types enabled",
                severity="medium",
                status="potential",
                description="Password/implicit grants should be disabled unless explicitly required and controlled.",
                evidence={"client_name": name, "client_id": c.get("client_id"), "grant_types": risky_grants},
                recommendation="Prefer Authorization Code + PKCE and disable legacy grants.",
            ))
        if c.get("oidc_conformant") is False:
            findings.append(Finding(
                title="Auth0 client is not OIDC conformant",
                severity="medium",
                status="potential",
                evidence={"client_name": name, "client_id": c.get("client_id")},
                recommendation="Enable OIDC conformant behavior or migrate legacy clients.",
            ))

    findings.append(Finding(
        title="Auth0 clients reviewed",
        severity="info",
        status="observed",
        evidence={"client_count": len(clients)},
    ))
    return findings


def audit_connections(base: str, token: str) -> List[Finding]:
    findings: List[Finding] = []
    fields = "name,strategy,enabled_clients,options"
    try:
        conns = paged_get(base, token, "/connections", {"fields": fields, "include_fields": "true"})
    except Exception as exc:
        return [Finding(
            title="Auth0 connections fetch failed",
            severity="info",
            status="error",
            evidence={"error": redact_text(str(exc), 700)},
        )]

    for conn in conns:
        strategy = conn.get("strategy")
        name = conn.get("name")
        enabled_clients = conn.get("enabled_clients") or []
        options = conn.get("options") or {}
        if strategy in {"auth0", "email", "sms"} and options.get("disable_signup") is not True:
            findings.append(Finding(
                title="Database/passwordless connection may allow signup",
                severity="medium",
                status="potential",
                description="If the application is invite-only or domain-restricted, direct database/passwordless signup should be explicitly disabled or blocked in a correct trigger.",
                evidence={"connection": name, "strategy": strategy, "enabled_client_count": len(enabled_clients), "disable_signup": options.get("disable_signup")},
                recommendation="Disable unintended signup paths and enforce allowlists in blocking flows and post-login checks for social/enterprise provisioning.",
            ))
        if len(enabled_clients) > 10:
            findings.append(Finding(
                title="Connection enabled for many clients",
                severity="low",
                status="potential",
                description="Connections enabled across many clients can indicate tenant drift or unintended application access.",
                evidence={"connection": name, "strategy": strategy, "enabled_client_count": len(enabled_clients)},
                recommendation="Restrict each connection to only the applications that should use it.",
            ))

    findings.append(Finding(
        title="Auth0 connections reviewed",
        severity="info",
        status="observed",
        evidence={"connection_count": len(conns)},
    ))
    return findings


def audit_resource_servers(base: str, token: str) -> List[Finding]:
    findings: List[Finding] = []
    try:
        servers = paged_get(base, token, "/resource-servers", {})
    except Exception as exc:
        return [Finding(
            title="Auth0 resource servers fetch failed",
            severity="info",
            status="error",
            evidence={"error": redact_text(str(exc), 700)},
        )]

    for srv in servers:
        name = srv.get("name") or srv.get("identifier")
        if srv.get("allow_offline_access"):
            findings.append(Finding(
                title="API allows offline access / refresh tokens",
                severity="low",
                status="observed",
                description="Offline access may be appropriate but should be limited to clients that need long-lived access, with rotation/reuse detection where applicable.",
                evidence={"api": name, "identifier": srv.get("identifier")},
                recommendation="Review refresh-token policy, token lifetime, and client restrictions.",
            ))
        scopes = srv.get("scopes") or []
        broad = [s for s in scopes if str(s.get("value", "")).lower() in {"admin", "*", "write:*", "read:*"}]
        if broad:
            findings.append(Finding(
                title="API defines broad-looking scopes",
                severity="low",
                status="potential",
                evidence={"api": name, "identifier": srv.get("identifier"), "scopes": broad},
                recommendation="Use precise least-privilege scopes and enforce them server-side.",
            ))
    findings.append(Finding(
        title="Auth0 APIs/resource servers reviewed",
        severity="info",
        status="observed",
        evidence={"resource_server_count": len(servers)},
    ))
    return findings


def audit_grants(base: str, token: str) -> List[Finding]:
    findings: List[Finding] = []
    try:
        grants = paged_get(base, token, "/client-grants", {})
    except Exception as exc:
        return [Finding(
            title="Auth0 client grants fetch failed",
            severity="info",
            status="error",
            evidence={"error": redact_text(str(exc), 700)},
        )]
    for grant in grants:
        scopes = grant.get("scope") or []
        write_scopes = [s for s in scopes if str(s).startswith(WRITE_SCOPE_PREFIXES)]
        if write_scopes:
            findings.append(Finding(
                title="Client grant includes Management/API write scopes",
                severity="medium",
                status="potential",
                description="Machine-to-machine clients with write scopes can be high impact if secrets are leaked or misused.",
                evidence={"client_id": grant.get("client_id"), "audience": grant.get("audience"), "write_scopes": write_scopes},
                recommendation="Apply least privilege, rotate secrets, and monitor Management API write events.",
            ))
    findings.append(Finding(
        title="Auth0 client grants reviewed",
        severity="info",
        status="observed",
        evidence={"client_grant_count": len(grants)},
    ))
    return findings


def run_auth0_audit(cfg: AuditorConfig, token_env: Optional[str] = None) -> List[Finding]:
    token_env = token_env or cfg.auth0_management.token_env
    token = os.environ.get(token_env)
    if not token:
        return [Finding(
            title="Auth0 Management API token not provided",
            severity="info",
            status="skipped",
            description="Set a read-only Management API token in the configured environment variable to run tenant configuration checks.",
            evidence={"token_env": token_env},
            recommendation="Use read-only scopes such as read:clients, read:connections, read:resource_servers, read:client_grants.",
        )]

    base = management_base(cfg)
    findings: List[Finding] = []
    findings.append(Finding(
        title="Auth0 read-only audit started",
        severity="info",
        status="observed",
        description="The tool will only perform GET requests against the Management API.",
        evidence={"management_api_base": base, "token_env": token_env},
    ))
    findings.extend(audit_clients(base, token))
    findings.extend(audit_connections(base, token))
    findings.extend(audit_resource_servers(base, token))
    findings.extend(audit_grants(base, token))
    return findings
