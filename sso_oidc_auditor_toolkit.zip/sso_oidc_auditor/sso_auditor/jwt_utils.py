from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from .config import AuditorConfig
from .reporting import Finding
from .util import DEFAULT_TIMEOUT, USER_AGENT, b64url_decode, b64url_encode, redact_text, redact_value


def split_jwt(token: str) -> tuple[Dict[str, Any], Dict[str, Any], str]:
    parts = token.strip().split(".")
    if len(parts) != 3:
        raise ValueError("JWT must contain header.payload.signature")
    header = json.loads(b64url_decode(parts[0]))
    payload = json.loads(b64url_decode(parts[1]))
    return header, payload, parts[2]


def read_token(token: Optional[str] = None, token_file: Optional[str] = None) -> str:
    if token:
        return token.strip()
    if token_file:
        return Path(token_file).read_text(encoding="utf-8").strip()
    raise ValueError("Provide --token or --token-file")


def lint_jwt(cfg: Optional[AuditorConfig], token: str) -> List[Finding]:
    findings: List[Finding] = []
    try:
        header, payload, sig = split_jwt(token)
    except Exception as exc:
        return [Finding(
            title="JWT parse failed",
            severity="info",
            status="error",
            evidence={"error": redact_text(str(exc), 500)},
        )]

    alg = str(header.get("alg", ""))
    kid = header.get("kid")
    now = int(time.time())
    exp = payload.get("exp")
    nbf = payload.get("nbf")
    iat = payload.get("iat")

    findings.append(Finding(
        title="JWT decoded without verification",
        severity="info",
        status="observed",
        description="Header and claims were decoded for review. This does not prove the token is valid; use --verify for signature and claim validation where possible.",
        evidence={"header": header, "claims": payload, "signature_present": bool(sig)},
    ))

    if alg.lower() == "none":
        findings.append(Finding(
            title="JWT uses alg=none",
            severity="high",
            status="observed",
            description="A JWT with alg=none must not be accepted for authentication or authorization.",
            evidence={"header": header},
            recommendation="Allowlist expected signing algorithms and reject unsigned tokens.",
        ))

    if alg.upper().startswith("HS"):
        findings.append(Finding(
            title="JWT uses symmetric HMAC algorithm",
            severity="low",
            status="observed",
            description="HMAC-signed tokens can be valid, but mixed HS/RS environments often create algorithm-confusion risk if validators are poorly configured.",
            evidence={"alg": alg, "kid": kid},
            recommendation="Ensure validators use a fixed algorithm allowlist and the correct key type.",
        ))

    if exp is not None and isinstance(exp, int) and exp < now:
        findings.append(Finding(
            title="JWT is expired",
            severity="info",
            status="observed",
            evidence={"exp": exp, "now": now},
        ))
    if nbf is not None and isinstance(nbf, int) and nbf > now:
        findings.append(Finding(
            title="JWT not yet valid",
            severity="info",
            status="observed",
            evidence={"nbf": nbf, "now": now},
        ))
    if iat is not None and isinstance(iat, int) and iat > now + 300:
        findings.append(Finding(
            title="JWT issued-at is in the future",
            severity="low",
            status="potential",
            evidence={"iat": iat, "now": now},
        ))

    if cfg:
        token_iss = payload.get("iss")
        token_aud = payload.get("aud")
        if token_iss and token_iss != cfg.issuer:
            findings.append(Finding(
                title="JWT issuer differs from configured issuer",
                severity="medium",
                status="potential",
                evidence={"configured_issuer": cfg.issuer, "token_issuer": token_iss},
                recommendation="Reject ID/access tokens from unexpected issuers.",
            ))
        if cfg.audience and token_aud:
            auds = token_aud if isinstance(token_aud, list) else [token_aud]
            if cfg.audience not in auds and cfg.client_id not in auds:
                findings.append(Finding(
                    title="JWT audience does not match configured audience/client",
                    severity="medium",
                    status="potential",
                    evidence={"configured_audience": cfg.audience, "configured_client_id": cfg.client_id, "token_audience": token_aud},
                    recommendation="Reject tokens that do not target the application/API audience.",
                ))

    return findings


def verify_id_token(cfg: AuditorConfig, token: str, expected_nonce: Optional[str] = None) -> List[Finding]:
    try:
        import jwt  # type: ignore
        from jwt import PyJWKClient  # type: ignore
    except Exception:
        return [Finding(
            title="PyJWT is not installed; signature verification skipped",
            severity="info",
            status="skipped",
            recommendation="Install requirements.txt, including PyJWT[crypto], to enable --verify.",
        )]

    try:
        jwks_client = PyJWKClient(cfg.effective_jwks_uri())
        signing_key = jwks_client.get_signing_key_from_jwt(token)
        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256", "ES256"],
            audience=cfg.client_id,
            issuer=cfg.issuer,
            options={
                "require": ["exp", "iat", "iss", "aud", "sub"],
                "verify_signature": True,
                "verify_exp": True,
                "verify_aud": True,
                "verify_iss": True,
            },
            leeway=60,
        )
        if expected_nonce is not None and claims.get("nonce") != expected_nonce:
            return [Finding(
                title="ID Token signature valid but nonce mismatch",
                severity="high",
                status="potential",
                description="The ID Token cryptographically validates, but the nonce does not match the expected transaction nonce.",
                evidence={"expected_nonce": expected_nonce, "token_nonce": claims.get("nonce"), "claims": claims},
                recommendation="Bind nonce to the login transaction and reject mismatches.",
            )]
        return [Finding(
            title="ID Token verification succeeded",
            severity="info",
            status="passed",
            description="The token signature and core issuer/audience/time claims validated using the configured issuer and client_id.",
            evidence={"claims": claims},
        )]
    except Exception as exc:
        return [Finding(
            title="ID Token verification failed",
            severity="info",
            status="observed",
            evidence={"error": redact_text(str(exc), 800)},
            recommendation="Confirm issuer, client_id, token type, and JWKS configuration. A failed verification is expected for negative-test tokens.",
        )]


def make_jwt_variants(token: str) -> Dict[str, str]:
    header, payload, sig = split_jwt(token)
    variants: Dict[str, str] = {}

    none_header = dict(header)
    none_header["alg"] = "none"
    variants["alg_none"] = ".".join([
        b64url_encode(json.dumps(none_header, separators=(",", ":")).encode()),
        b64url_encode(json.dumps(payload, separators=(",", ":")).encode()),
        "",
    ])

    variants["invalid_signature"] = ".".join(token.strip().split(".")[:2] + ["invalidsignature"])

    wrong_iss_payload = dict(payload)
    wrong_iss_payload["iss"] = "https://wrong-issuer.example/"
    variants["wrong_issuer_invalid_signature"] = ".".join([
        b64url_encode(json.dumps(header, separators=(",", ":")).encode()),
        b64url_encode(json.dumps(wrong_iss_payload, separators=(",", ":")).encode()),
        "invalidsignature",
    ])

    wrong_aud_payload = dict(payload)
    wrong_aud_payload["aud"] = "wrong-audience"
    variants["wrong_audience_invalid_signature"] = ".".join([
        b64url_encode(json.dumps(header, separators=(",", ":")).encode()),
        b64url_encode(json.dumps(wrong_aud_payload, separators=(",", ":")).encode()),
        "invalidsignature",
    ])

    expired_payload = dict(payload)
    expired_payload["exp"] = 1
    variants["expired_invalid_signature"] = ".".join([
        b64url_encode(json.dumps(header, separators=(",", ":")).encode()),
        b64url_encode(json.dumps(expired_payload, separators=(",", ":")).encode()),
        "invalidsignature",
    ])
    return variants


def save_variants(token: str, out: str) -> Finding:
    variants = make_jwt_variants(token)
    Path(out).write_text(json.dumps(variants, indent=2), encoding="utf-8")
    return Finding(
        title="JWT negative-test variants generated",
        severity="info",
        status="observed",
        description="Variants were written locally for authorized negative testing. They are intentionally invalid except for the alg=none structure and should be rejected by any secure application.",
        evidence={"output_file": out, "variant_names": sorted(variants.keys())},
        recommendation="Use these only against your own test environment or explicitly authorized targets.",
    )
